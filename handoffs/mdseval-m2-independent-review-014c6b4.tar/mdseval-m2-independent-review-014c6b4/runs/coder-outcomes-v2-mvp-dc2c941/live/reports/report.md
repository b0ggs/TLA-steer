# CODER Outcome Evaluator V2 MVP

Verdict: **INCONCLUSIVE**
Run status: **COMPLETE**

## Control gates

- offline_null: PASS
- oracle_qualification: PASS
- aa: PASS
- known_better: PASS

## Real comparison

Macro pass@1: A=1.000, B=1.000; B−A=0.000; exact two-sided p=1/1

| Task | A pass@1 | B pass@1 | B−A |
|---|---:|---:|---:|
| add-execution-waves | 1.000 | 1.000 | 0.000 |
| add-period-summary | 1.000 | 1.000 | 0.000 |
| compare-scheduled-instants | 1.000 | 1.000 | 0.000 |
| deduplicate-running-balances | 1.000 | 1.000 | 0.000 |
| integrate-event-deliveries | 1.000 | 1.000 | 0.000 |
| integrate-warehouse-availability | 1.000 | 1.000 | 0.000 |
| refactor-context-merge | 1.000 | 1.000 | 0.000 |
| refactor-lazy-pagination | 1.000 | 1.000 | 0.000 |

## Efficiency

Launched calls: 56 (superseded: 0); wall time sum: 5599.688107s; total tokens: 10359259

This result applies only to the frozen eight-task synthetic Python repository pack and configuration.

Non-significance is not equivalence; this intentionally small MVP is likely inconclusive for modest differences.
