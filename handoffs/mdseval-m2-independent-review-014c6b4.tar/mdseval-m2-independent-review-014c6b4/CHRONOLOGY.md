# Factual chronology

1. An earlier frozen eight-task evaluation reported pass@1 of 1.0 for both
   conditions in its real comparison. A separate CODER.md-versus-no-MD run also
   reported pass@1 of 1.0 for both conditions. Both reports were inconclusive.
2. Milestone 2 introduced a no-MD calibration stage, twenty new tasks in four
   strata, deterministic task qualification, null and harmful controls, and a
   helpful requirement-coverage treatment.
3. Each task received six no-MD calibration attempts. A task was eligible for
   later selection only with 1–5 successes; four eligible tasks were required
   in every stratum.
4. The v0.4 campaign launched all 120 calibration calls. It was declared
   `INVALID` because four attempt event logs had evidence-capture defects. Its
   116 mechanically intact attempts are not confirmatory evidence, but the
   aggregate task pattern was available for development review.
5. The capture implementation was repaired without changing the tasks,
   treatment, wrapper, model, or statistical selection rule.
6. The authoritative v0.4.1 campaign launched all 120 calibration calls. It
   recorded no infrastructure or fatal evidence failures and stopped before
   the controls stage because the bug stratum had zero eligible tasks. Its
   terminal verdict was `SENSITIVITY_NOT_DEMONSTRATED`.

| Null-calibration outcome | v0.4 | v0.4.1 |
|---|---:|---:|
| Tasks solved 6/6 | 14 | 14 |
| Tasks solved 0/6 | 5 | 5 |
| Only intermediate task | integration-01: 1/6 | integration-01: 2/6 |

The v0.4.1 live and replay reports in this packet are byte-identical. No
controls-stage or helpful-stage calls were made in either M2 campaign.
