# MDs_EVAL Milestone 2 Independent-Review Handoff

This is a read-only evidence packet for an independent scientific critique of
the CODER.md evaluator. It was assembled from repository commit
`014c6b4c11979c583594734b32c1756535b78221`. It is not an implementation packet
and does not authorize new model calls or changes to the experiment.

Start with `INDEPENDENT_REVIEW_PROMPT.md`, then use `CHRONOLOGY.md` as a factual
orientation. Inspect the source evidence rather than treating either document
as a conclusion.

## Contents

- Scientific design: `MD_EVAL_PROJECT_ROADMAP.md`,
  `CODER_BENEFICIAL_SENSITIVITY_PROTOCOL.md`,
  `CODER_BENEFICIAL_SENSITIVITY_M2_IMPLEMENTATION_PLAN.md`, and the frozen
  configuration in `experiments/coder-beneficial-sensitivity-m2.json`.
- External context: `MD_EVAL_EXPERIMENT_REDESIGN_REQUIREMENTS.md` was untracked
  at assembly time and is non-authoritative. It is included only as external
  context.
- Treatments and shared wrapper: `controls/coder/` and
  `src/mdseval/wrapper.py`. The N/H/P treatments are the empty null file,
  no-implementation harmful control, and helpful requirement-coverage file;
  the P-treatment authorship record is included beside it.
- Tasks and qualification oracles: the complete
  `evals/m2/coder-beneficial-sensitivity/` and
  `evals/qualification/coder-beneficial-sensitivity-m2/` trees. The latter
  tree's `validation.json` is earlier, pre-correction task-validator history;
  it recorded blockers and is not the final authoritative qualification.
- Prior ceiling evidence: the live reports under the two
  `runs/coder-outcomes-v2-*` directories.
- M2 evidence: aggregate calibration trajectories, calibration receipts and
  outcome locks, and reports for v0.4 and v0.4.1. The v0.4.1 offline-replay
  reports are also included. Final v0.4.1 aggregate qualification evidence is
  under `runs/coder-beneficial-sensitivity-m2-v041-014c6b4/live/qualification/`:
  `qualification-receipt.json`, `qualification-results.json`, and
  `freeze-record.json`. Per-attempt qualification and campaign directories and
  concealed plaintext mappings are intentionally excluded.
- Integrity: `MANIFEST.sha256` covers every payload file except itself.

The reviewer who reads this packet will know task-level outcomes. That review
may guide development, but it must not be presented as independent authorship
of a future confirmatory task set.
