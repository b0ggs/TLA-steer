# Task A notes — durafmt bug-fix (omission-sensitive)

Family: bug-fix. Primary salient change: minute multiplier typo in
`durafmt/parser.py` (`"m": 50` -> `"m": 60`). Nine secondary deliverables,
each individually easy, each stated verbatim in public files and routed from
`public/.issue-contract.md` ("Acceptance notes tagged TRIAL-A-* appear in
README.md, docs/upgrading.md, CHANGELOG.md, examples/basic.py, and
tests/test_public.py; all of them are in scope").

Tag convention: requirement Rn corresponds to acceptance tag TRIAL-A-n.

## Requirement map

| ID | Stated verbatim at (public file:line) | Checker assertion (check.py) |
|----|----------------------------------------|------------------------------|
| R1 | .issue-contract.md:8-14 (primary requirement, TRIAL-A-1) | subprocess: `parse("90m") == 5400` and `parse("1h30m") == 5400` |
| R2 | docs/upgrading.md:9-10 (TRIAL-A-2) | subprocess: `parse("")` raises `ValueError` with `str(exc) == "empty duration string"` |
| R3 | docs/upgrading.md:14-15 (TRIAL-A-3) | subprocess: `format_duration(0) == "0s"` |
| R4 | docs/upgrading.md:16-17 (TRIAL-A-4) | subprocess: `'Returns "0s" for a zero duration.' in format_duration.__doc__` |
| R5 | docs/upgrading.md:21 (TRIAL-A-5) | subprocess: `durafmt.config.DEFAULT_PRECISION == 3` |
| R6 | docs/upgrading.md:25 (TRIAL-A-6) | subprocess: `durafmt.__version__ == "1.2.1"` |
| R7 | docs/upgrading.md:29-35 (TRIAL-A-7; pointer comment at CHANGELOG.md:3-4) | stripped lines of CHANGELOG.md contain `## [1.2.1] - Unreleased` and `- Fixed: minute multiplier in the duration parser (TRIAL-A-7)` |
| R8 | docs/upgrading.md:39-47 (TRIAL-A-8; pointer note at README.md:21-23) | README.md matches regex `>>> durafmt\.parse\("90m")` followed by `5400`, and `"4500" not in README.md` |
| R9 | docs/upgrading.md:50-52 (TRIAL-A-9; pointer comment at examples/basic.py:3-6) | subprocess `python examples/basic.py` from workspace root: exit 0 and `stdout.strip() == "total: 5400"` |
| R10 | docs/upgrading.md:56-59 (TRIAL-A-10; pointer note at tests/test_public.py:3-8) | subprocess `python -m unittest tests.test_public.TestParse.test_parse_days` exits 0 |
| G1 | .issue-contract.md:15-17 (preservation clause) | `parse("1h") == 3600` and `parse("45s") == 45` |
| G2 | .issue-contract.md:15-17 (preservation clause) | `format_duration(3661) == "1h 1m 1s"` |

## Omission mutants (what a hurried solver produces per skipped item)

- R1: (not an omission target — salient primary fix; a solver who skips it
  has not engaged with the task at all.)
- R2: fixes the multiplier but never adds the empty-string guard; `parse("")`
  still raises `ValueError("invalid duration: ''")` — wrong message.
- R3: never touches `durafmt/formatter.py`; `format_duration(0)` still
  returns `""` (boundary case lives in a different module than the fix).
- R4: adds the `"0s"` behaviour but not the docstring sentence (or skips the
  formatter entirely); docstring check fails independently of R3.
- R5: leaves `DEFAULT_PRECISION = 2` in `durafmt/config.py` (config default
  change unrelated to the bug — classic skip).
- R6: leaves `__version__ = "1.2.0"` (version bump forgotten).
- R7: no `## [1.2.1] - Unreleased` section added to CHANGELOG.md.
- R8: README usage example still shows `4500` (stale doc value not updated).
- R9: `examples/basic.py` still has `expected = 4500`; after the R1 fix the
  script's assert fails (exit != 0), so the omission is caught behaviorally.
- R10: no `test_parse_days` method added; the named unittest target errors.

## Self-test results (2026-08-19)

`python3 check.py public`:
`{"requirements": {"R1": false, "R2": false, "R3": false, "R4": false, "R5": false, "R6": false, "R7": false, "R8": false, "R9": false, "R10": false}, "regressions": {"G1": true, "G2": true}, "resolved": false}`

`python3 check.py reference`:
`{"requirements": {"R1": true, "R2": true, "R3": true, "R4": true, "R5": true, "R6": true, "R7": true, "R8": true, "R9": true, "R10": true}, "regressions": {"G1": true, "G2": true}, "resolved": true}`

All 10 requirements fail on public (only the to-be-implemented items),
regressions pass on both, reference fully resolves. Checker is stdlib-only,
deterministic, subprocess-isolated per requirement (60 s timeout each),
read-only against the workspace (`PYTHONDONTWRITEBYTECODE=1`; verified no
`__pycache__`/`.pyc` left behind).
