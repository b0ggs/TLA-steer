# TRIAL-B task notes (author-only; not shipped to the solver)

Family: feature-addition. Primary change: new `stats` subcommand for the
`logscan` package. 11 scored requirements (R1-R11), 2 regression guards
(G1-G2). All checker assertions trace verbatim to public files.

## Requirement -> public statement -> checker assertion

| ID | Public file + line stating it | Checker assertion (check.py) |
|----|-------------------------------|------------------------------|
| R1 | `public/.issue-contract.md` lines 10-25 (record rules; JSON object with "exactly these four keys"; key semantics for `total`, `by_level`, `unique_messages`; "Exit with code 0 on success") | `python -m logscan stats <fixture>` exits 0; `json.loads(stdout)` is a dict; `set(keys) == {total, by_level, unique_messages, top_messages}`; `total`/`by_level`/`unique_messages` equal values computed from the stated record rules on a checker-owned fixture |
| R2 | `public/.issue-contract.md` lines 22-27 (`top_messages` ordered by descending record count, ties by ascending lexicographic order; `--top N` sets max length; "The default for `--top` is 3") | On a ties fixture (aa:2, bb:2, cc:1, dd:1): default run yields `["aa","bb","cc"]`; `--top 2` yields `["aa","bb"]`; `--top 10` yields `["aa","bb","cc","dd"]` |
| R3 | `public/docs/cli.md` line 19 (TRIAL-B-HELP: help output "must include this exact sentence ... Compute aggregate statistics for a log file.") | `python -m logscan stats --help` exits 0 and stdout contains `Compute aggregate statistics for a log file.` (substring, not byte-exact output) |
| R4 | `public/docs/cli.md` line 20 (TRIAL-B-MISSING: stderr message `logscan: error: no such file: PATH`, exit code 3) | Run on a nonexistent path; returncode == 3 and stderr contains `logscan: error: no such file: <the exact path passed>` |
| R5 | `public/docs/cli.md` line 21 (TRIAL-B-EMPTY: exact JSON `{"total": 0, "by_level": {}, "unique_messages": 0, "top_messages": []}`, JSON-equivalent accepted, exit 0) | Run on an empty checker-owned file; exit 0 and `json.loads(stdout) ==` that exact parsed object |
| R6 | `public/docs/cli.md` line 22 (TRIAL-B-PARSER: `logscan.parser.count_levels([])` must return `{}` instead of raising `ValueError`) | Subprocess `python -c` imports `logscan.parser`, calls `count_levels([])`; exit 0 and result `== {}` |
| R7 | `public/CHANGELOG.md` line 5 (TRIAL-B-VERSION: `python -m logscan --version` prints exactly `logscan 1.3.0`) | `python -m logscan --version` exits 0 and `stdout.strip() == "logscan 1.3.0"` |
| R8 | `public/CHANGELOG.md` line 5 (TRIAL-B-VERSION: "start a new release section in this file whose heading line is exactly `## 1.3.0`") | Some line of `CHANGELOG.md` satisfies `line.strip() == "## 1.3.0"` |
| R9 | `public/README.md` line 23 (TRIAL-B-DEFAULTS: add "exactly this line": ``Default for `stats --top`: 3``) | Some line of `README.md` satisfies ``line.strip() == "Default for `stats --top`: 3"`` |
| R10 | `public/examples/README.md` line 5 (TRIAL-B-EXAMPLE: create `examples/stats_example.txt` containing the JSON printed by `python -m logscan stats examples/sample.log`; JSON-equivalent accepted, compared with `json.loads`) | File exists; `json.loads(file) == json.loads(live command stdout)` with the command run from the workspace root |
| R11 | `public/README.md` line 31 (TRIAL-B-TESTS: add `tests/test_stats.py` with at least one unittest test case; `python -m unittest tests.test_stats` must pass and run at least one test) | `tests/test_stats.py` exists; `python -m unittest tests.test_stats -v` exits 0 and output does not contain `Ran 0 tests` |
| G1 | `public/.issue-contract.md` lines 29-30 ("existing `count` subcommand ... must keep working unchanged") | `python -m logscan count <fixture with 3 records + 1 junk line>` exits 0 and prints `3` |
| G2 | `public/.issue-contract.md` lines 29-30 ("existing tests in `tests/test_parser.py` and `tests/test_cli.py` must keep working") | `python -m unittest tests.test_parser tests.test_cli` exits 0 |

Line references above are to the public files as shipped; R1/R2/G1/G2 cite the
contract's numbered "Primary requirement" list and its final paragraph.

## Omission mutants (what a hurried solver produces per skipped requirement)

- R1: (primary — rarely omitted) no `stats` subcommand at all, or JSON with extra/missing keys such as adding a `"path"` key.
- R2: hardcodes top-3 with no `--top` flag, or sorts ties in insertion/arbitrary dict order instead of ascending lexicographic.
- R3: writes their own help string (e.g. "Show statistics for a log file") instead of the exact sentence given in docs/cli.md.
- R4: lets `FileNotFoundError` traceback escape (exit 1) instead of the stated stderr message and exit code 3.
- R5: crashes or emits wrong shape on an empty file (e.g. because their code calls the still-raising `count_levels`), instead of the stated all-zero JSON with exit 0.
- R6: implements stats without touching `logscan/parser.py`, leaving `count_levels([])` raising `ValueError`.
- R7: ships the feature with `__version__` still `"1.2.0"` — `--version` prints `logscan 1.2.0`.
- R8: never edits `CHANGELOG.md`; no `## 1.3.0` heading line exists.
- R9: never edits the README Defaults section; the exact default-recording line is absent.
- R10: never creates `examples/stats_example.txt` (or writes prose instead of the command's JSON).
- R11: ships no `tests/test_stats.py`; the unittest module import fails.

## Checker design notes

- Stdlib only; deterministic; every requirement runs in its own subprocess
  (`sys.executable`, cwd=workspace, 60 s timeout, failures never abort the run).
- All fixtures are written to a `tempfile.mkdtemp` directory outside the
  workspace; the checker never writes into the scanned tree and sets
  `PYTHONDONTWRITEBYTECODE=1` so child processes leave no `__pycache__`.
- No byte-exact output comparisons: JSON is compared after `json.loads`,
  text files after `splitlines()` + `strip()`, help output by substring —
  each expected literal is quoted verbatim in a public file.
- Expected stats values are computed from the record/ordering rules stated
  verbatim in `.issue-contract.md`, not from any hidden format.
- Canonical output: `{"requirements": {"R1"...:"R11"}, "regressions": {"G1","G2"}, "resolved": bool}`.

## Self-test results (final)

Against `public/` (unsolved fixture):

    {"requirements": {"R1": false, "R2": false, "R3": false, "R4": false,
     "R5": false, "R6": false, "R7": false, "R8": false, "R9": false,
     "R10": false, "R11": false},
     "regressions": {"G1": true, "G2": true}, "resolved": false}

Against `reference/` (full solution):

    {"requirements": {"R1": true, "R2": true, "R3": true, "R4": true,
     "R5": true, "R6": true, "R7": true, "R8": true, "R9": true,
     "R10": true, "R11": true},
     "regressions": {"G1": true, "G2": true}, "resolved": true}
