#!/usr/bin/env python3
"""Checker for issue TRIAL-B (logscan `stats` subcommand).

Usage: python3 check.py /path/to/workspace

Runs outside the workspace. Every assertion below corresponds verbatim to a
requirement stated in the workspace's public files (.issue-contract.md,
README.md, docs/cli.md, CHANGELOG.md, examples/README.md). Emits canonical
JSON on stdout:

    {"requirements": {"R1": bool, ...}, "regressions": {...}, "resolved": bool}
"""

import json
import os
import subprocess
import sys
import tempfile

TIMEOUT = 60
LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR")

# Checker-owned fixtures (written to a temp dir OUTSIDE the workspace).
BASIC = (
    "INFO alpha\n"
    "ERROR beta\n"
    "INFO alpha\n"
    "junk line\n"
    "WARNING gamma delta\n"
    "INFO omega\n"
    "\n"
    "DEBUG zeta\n"
)
TIES = "INFO bb\nINFO aa\nINFO bb\nINFO cc\nINFO aa\nINFO dd\n"
COUNT_FIXTURE = "INFO a\nnope\nERROR b\nDEBUG c\n"

# Stated verbatim in docs/cli.md (TRIAL-B-EMPTY).
EMPTY_SUMMARY = {"total": 0, "by_level": {}, "unique_messages": 0, "top_messages": []}
# Stated in .issue-contract.md ("exactly these four keys").
KEYS = {"total", "by_level", "unique_messages", "top_messages"}
# Stated verbatim in docs/cli.md (TRIAL-B-HELP).
HELP_SENTENCE = "Compute aggregate statistics for a log file."
# Stated verbatim in CHANGELOG.md (TRIAL-B-VERSION).
VERSION_LINE = "logscan 1.3.0"
HEADING_LINE = "## 1.3.0"
# Stated verbatim in README.md (TRIAL-B-DEFAULTS).
README_LINE = "Default for `stats --top`: 3"


def run(ws, args, timeout=TIMEOUT):
    """Run `python <args>` with cwd=workspace in a fresh subprocess."""
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        return subprocess.run(
            [sys.executable] + args,
            cwd=ws,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None


def parse_records(text):
    """Record rules exactly as stated in .issue-contract.md item 1."""
    records = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        parts = line.split(" ", 1)
        if len(parts) == 2 and parts[0] in LEVELS and parts[1]:
            records.append((parts[0], parts[1]))
    return records


def summarize(records, top=3):
    """Payload rules exactly as stated in .issue-contract.md item 2/4."""
    by_level = {}
    msg = {}
    for level, message in records:
        by_level[level] = by_level.get(level, 0) + 1
        msg[message] = msg.get(message, 0) + 1
    return {
        "total": len(records),
        "by_level": by_level,
        "unique_messages": len(msg),
        "top_messages": sorted(msg, key=lambda m: (-msg[m], m))[:top],
    }


def stats_json(ws, path, extra=()):
    """Run `python -m logscan stats <path> [extra]`; return dict or None."""
    r = run(ws, ["-m", "logscan", "stats", path] + list(extra))
    if r is None or r.returncode != 0:
        return None
    try:
        data = json.loads(r.stdout)
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def read_lines(ws, relpath):
    try:
        with open(os.path.join(ws, relpath), "r", encoding="utf-8") as fh:
            return fh.read().splitlines()
    except OSError:
        return None


def main():
    if len(sys.argv) != 2:
        print("usage: check.py WORKSPACE", file=sys.stderr)
        sys.exit(2)
    ws = os.path.abspath(sys.argv[1])

    tmp = tempfile.mkdtemp(prefix="trialb-fixtures-")

    def fixture(name, content):
        p = os.path.join(tmp, name)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(content)
        return p

    basic_log = fixture("basic.log", BASIC)
    ties_log = fixture("ties.log", TIES)
    empty_log = fixture("empty.log", "")
    count_log = fixture("count.log", COUNT_FIXTURE)
    missing_log = os.path.join(tmp, "does-not-exist.log")

    requirements = {}
    regressions = {}

    def req(key, fn):
        try:
            requirements[key] = bool(fn())
        except Exception:
            requirements[key] = False

    def reg(key, fn):
        try:
            regressions[key] = bool(fn())
        except Exception:
            regressions[key] = False

    # R1 — contract items 1-3: stats exits 0, prints one JSON object with
    # exactly the four stated keys and correct total/by_level/unique_messages.
    def r1():
        data = stats_json(ws, basic_log)
        if data is None or set(data.keys()) != KEYS:
            return False
        exp = summarize(parse_records(BASIC))
        return (
            data["total"] == exp["total"]
            and data["by_level"] == exp["by_level"]
            and data["unique_messages"] == exp["unique_messages"]
        )

    req("R1", r1)

    # R2 — contract items 2/4: top_messages ordering (descending count, ties
    # by ascending lexicographic order), --top N honored, default --top is 3.
    def r2():
        default = stats_json(ws, ties_log)
        top2 = stats_json(ws, ties_log, ["--top", "2"])
        top10 = stats_json(ws, ties_log, ["--top", "10"])
        if default is None or top2 is None or top10 is None:
            return False
        return (
            default.get("top_messages") == ["aa", "bb", "cc"]
            and top2.get("top_messages") == ["aa", "bb"]
            and top10.get("top_messages") == ["aa", "bb", "cc", "dd"]
        )

    req("R2", r2)

    # R3 — docs/cli.md TRIAL-B-HELP: `stats --help` includes the exact sentence.
    def r3():
        r = run(ws, ["-m", "logscan", "stats", "--help"])
        return r is not None and r.returncode == 0 and HELP_SENTENCE in r.stdout

    req("R3", r3)

    # R4 — docs/cli.md TRIAL-B-MISSING: missing file -> stated stderr message,
    # exit code 3.
    def r4():
        r = run(ws, ["-m", "logscan", "stats", missing_log])
        if r is None or r.returncode != 3:
            return False
        return ("logscan: error: no such file: " + missing_log) in r.stderr

    req("R4", r4)

    # R5 — docs/cli.md TRIAL-B-EMPTY: empty file -> stated JSON, exit 0.
    def r5():
        data = stats_json(ws, empty_log)
        return data == EMPTY_SUMMARY

    req("R5", r5)

    # R6 — docs/cli.md TRIAL-B-PARSER: count_levels([]) returns {}.
    def r6():
        code = (
            "import json\n"
            "from logscan import parser\n"
            "print(json.dumps(parser.count_levels([])))\n"
        )
        r = run(ws, ["-c", code])
        return r is not None and r.returncode == 0 and json.loads(r.stdout) == {}

    req("R6", r6)

    # R7 — CHANGELOG.md TRIAL-B-VERSION: `--version` prints exactly
    # "logscan 1.3.0".
    def r7():
        r = run(ws, ["-m", "logscan", "--version"])
        return r is not None and r.returncode == 0 and r.stdout.strip() == VERSION_LINE

    req("R7", r7)

    # R8 — CHANGELOG.md TRIAL-B-VERSION: new section whose heading line is
    # exactly "## 1.3.0".
    def r8():
        lines = read_lines(ws, "CHANGELOG.md")
        return lines is not None and any(l.strip() == HEADING_LINE for l in lines)

    req("R8", r8)

    # R9 — README.md TRIAL-B-DEFAULTS: exact line present in README.md.
    def r9():
        lines = read_lines(ws, "README.md")
        return lines is not None and any(l.strip() == README_LINE for l in lines)

    req("R9", r9)

    # R10 — examples/README.md TRIAL-B-EXAMPLE: examples/stats_example.txt is
    # JSON-equivalent to the live output of
    # `python -m logscan stats examples/sample.log` run from the repo root.
    def r10():
        example_path = os.path.join(ws, "examples", "stats_example.txt")
        if not os.path.isfile(example_path):
            return False
        r = run(ws, ["-m", "logscan", "stats", os.path.join("examples", "sample.log")])
        if r is None or r.returncode != 0:
            return False
        with open(example_path, "r", encoding="utf-8") as fh:
            file_data = json.loads(fh.read())
        return file_data == json.loads(r.stdout)

    req("R10", r10)

    # R11 — README.md TRIAL-B-TESTS: tests/test_stats.py exists,
    # `python -m unittest tests.test_stats` passes and runs at least one test.
    def r11():
        if not os.path.isfile(os.path.join(ws, "tests", "test_stats.py")):
            return False
        r = run(ws, ["-m", "unittest", "tests.test_stats", "-v"])
        if r is None or r.returncode != 0:
            return False
        combined = r.stdout + r.stderr
        return "Ran 0 tests" not in combined

    req("R11", r11)

    # G1 — contract: existing `count` subcommand keeps working unchanged.
    def g1():
        r = run(ws, ["-m", "logscan", "count", count_log])
        return r is not None and r.returncode == 0 and r.stdout.strip() == "3"

    reg("G1", g1)

    # G2 — contract: existing tests keep passing.
    def g2():
        r = run(ws, ["-m", "unittest", "tests.test_parser", "tests.test_cli"])
        return r is not None and r.returncode == 0

    reg("G2", g2)

    resolved = all(requirements.values()) and all(regressions.values())
    print(
        json.dumps(
            {
                "requirements": requirements,
                "regressions": regressions,
                "resolved": resolved,
            }
        )
    )


if __name__ == "__main__":
    main()
