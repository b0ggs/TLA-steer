"""Aggregate statistics for parsed log records."""


def summarize(records, top=3):
    """Return the stats payload for a list of ``(level, message)`` records.

    Keys: total, by_level, unique_messages, top_messages. ``top_messages``
    holds up to ``top`` distinct messages ordered by descending record count,
    ties broken by ascending lexicographic (codepoint) order.
    """
    by_level = {}
    message_counts = {}
    for level, message in records:
        by_level[level] = by_level.get(level, 0) + 1
        message_counts[message] = message_counts.get(message, 0) + 1
    top_messages = sorted(
        message_counts, key=lambda m: (-message_counts[m], m)
    )[:top]
    return {
        "total": len(records),
        "by_level": by_level,
        "unique_messages": len(message_counts),
        "top_messages": top_messages,
    }
