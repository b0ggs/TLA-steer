import unittest

from logscan import stats


class SummarizeTest(unittest.TestCase):
    def test_basic_summary(self):
        records = [("INFO", "a"), ("INFO", "b"), ("ERROR", "a")]
        result = stats.summarize(records, top=2)
        self.assertEqual(result["total"], 3)
        self.assertEqual(result["by_level"], {"INFO": 2, "ERROR": 1})
        self.assertEqual(result["unique_messages"], 2)
        self.assertEqual(result["top_messages"], ["a", "b"])

    def test_empty_records(self):
        self.assertEqual(
            stats.summarize([]),
            {
                "total": 0,
                "by_level": {},
                "unique_messages": 0,
                "top_messages": [],
            },
        )


if __name__ == "__main__":
    unittest.main()
