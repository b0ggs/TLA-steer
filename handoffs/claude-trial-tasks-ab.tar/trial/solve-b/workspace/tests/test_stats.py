import io
import json
import os
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout

from logscan import cli, parser


def _run(argv):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        rc = cli.main(argv)
    return rc, out.getvalue(), err.getvalue()


def _write(td, name, text):
    path = os.path.join(td, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path


class StatsCommandTest(unittest.TestCase):
    def test_basic_stats(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write(
                td,
                "a.log",
                "INFO a\nINFO b\njunk\nERROR a\nWARNING c\nINFO a\n",
            )
            rc, out, _err = _run(["stats", path])
            self.assertEqual(rc, 0)
            payload = json.loads(out)
            self.assertEqual(
                payload,
                {
                    "total": 5,
                    "by_level": {"INFO": 3, "ERROR": 1, "WARNING": 1},
                    "unique_messages": 3,
                    "top_messages": ["a", "b", "c"],
                },
            )

    def test_tie_break_is_lexicographic(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write(td, "a.log", "INFO b\nINFO a\nERROR b\nERROR a\n")
            rc, out, _err = _run(["stats", path, "--top", "2"])
            self.assertEqual(rc, 0)
            self.assertEqual(json.loads(out)["top_messages"], ["a", "b"])

    def test_top_flag_limits_list(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write(td, "a.log", "INFO a\nINFO a\nINFO b\nINFO c\n")
            rc, out, _err = _run(["stats", path, "--top", "1"])
            self.assertEqual(rc, 0)
            self.assertEqual(json.loads(out)["top_messages"], ["a"])

    def test_default_top_is_three(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write(td, "a.log", "INFO a\nINFO b\nINFO c\nINFO d\n")
            rc, out, _err = _run(["stats", path])
            self.assertEqual(rc, 0)
            self.assertEqual(json.loads(out)["top_messages"], ["a", "b", "c"])

    def test_empty_file(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write(td, "empty.log", "")
            rc, out, _err = _run(["stats", path])
            self.assertEqual(rc, 0)
            self.assertEqual(
                json.loads(out),
                {
                    "total": 0,
                    "by_level": {},
                    "unique_messages": 0,
                    "top_messages": [],
                },
            )

    def test_no_parseable_records(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write(td, "junk.log", "junk\nmore junk\n\n")
            rc, out, _err = _run(["stats", path])
            self.assertEqual(rc, 0)
            self.assertEqual(json.loads(out)["total"], 0)

    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "nope.log")
            rc, out, err = _run(["stats", path])
            self.assertEqual(rc, 3)
            self.assertEqual(out, "")
            self.assertIn("logscan: error: no such file: " + path, err)

    def test_help_contains_required_sentence(self):
        out = io.StringIO()
        with redirect_stdout(out):
            with self.assertRaises(SystemExit) as ctx:
                cli.main(["stats", "--help"])
        self.assertEqual(ctx.exception.code, 0)
        self.assertIn(
            "Compute aggregate statistics for a log file.", out.getvalue()
        )


class CountLevelsEmptyTest(unittest.TestCase):
    def test_empty_records_return_empty_mapping(self):
        self.assertEqual(parser.count_levels([]), {})


if __name__ == "__main__":
    unittest.main()
