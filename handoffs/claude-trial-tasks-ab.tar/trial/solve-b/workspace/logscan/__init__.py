"""logscan: a tiny, dependency-free log analysis toolkit."""

__version__ = "1.3.0"
