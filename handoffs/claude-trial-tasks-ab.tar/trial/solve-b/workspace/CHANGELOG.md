# Changelog

## Unreleased

## 1.3.0

- Added the `stats` subcommand (`python -m logscan stats PATH [--top N]`),
  which prints aggregate statistics for a log file as a single JSON object.
- `logscan.parser.count_levels([])` now returns `{}` instead of raising
  `ValueError`.

## 1.2.0

- Added the `count` subcommand.

## 1.1.0

- Initial release: record parser.
