# Outside review: repository-instruction benchmark

This package is intended for an independent reviewer who has no prior knowledge
of the project. The two interpretations below are presented as competing
explanations of the same evidence. This document does not choose between them.

## 1. Product goal

The goal is an open-source benchmark that answers a practical question: for a
particular coding agent, does a repository instruction file such as `CODER.md` or
`AGENTS.md` help, harm, or cost money?

The benchmark gives the same model the same coding work under controlled
conditions. A bare arm has no repository instruction file. An instruction-file
arm adds one specified file. A later comparison can test an existing file
against a proposed replacement. Automated checks determine whether the requested
work was completed and whether existing behavior was preserved. The run record
also captures tokens and time so equal completion can still reveal a cost.

The intended deliverable is a reusable collection of tasks, a controlled runner,
objective checks, preserved raw evidence, and a comparison report that supports
a keep, replace, or remove decision. It is not yet a system that writes or
optimizes instruction files.

## 2. Full experimental record for gpt-5.6-sol

In this table, a call is one attempt by the tested model. A result is valid only
when the task description and automated check agree. “Resolved” means every
stated requirement and regression check passed. The symbol `q` is the fraction
of individual requirement checks that passed across the attempts. A ceiling
means all attempts resolved, leaving no completion improvement for an
instruction file to show. Invalid results remain part of the record but are not
treated as model failures.

| Experiment, in chronological order | Calls | Fairness status | Result | What the result supports |
|---|---:|---|---|---|
| M2 v0.4 and v0.4.1 | 240 | Fourteen of twenty tasks had sound checks. Six had hidden or over-exact requirements. | Each of the fourteen sound tasks resolved 6/6 in both campaigns. Five flawed tasks produced apparent 0/6 floors. The flawed `integration-01` moved from 1/6 to 2/6 because its check required an unstated byte-exact JSON format. | The sound portion was at ceiling. The apparent floors and intermediate JSON result were invalid for judging model ability. |
| `scout-v1` | 18 | Three tasks were sound ceilings; `scout-c-integration-01` was also sound; two author-a tasks were later excluded because the task wrapper contradicted the intended file scope. | The three ceiling tasks resolved 3/3. `scout-c-integration-01` resolved 1/3 and passed 22/24 requirement observations (`q=0.9167`), missing a publicly stated test twice. The two excluded tasks resolved 0/3. | This is the one documented legitimate intermediate completion result, but it did not produce a repeatable task band. The two apparent floors were invalid. |
| `rolling-01`, event-rollup task | 3 | Invalid: the check counted evaluator-created Git metadata. | The observed outcome was invalidated. | Checker defect; no conclusion about model ability. |
| `rolling-02` | 3 | Invalid: the check required an unpublished module-level `sys` import. | The observed outcome was invalidated. | Hidden requirement; no conclusion about model ability. |
| `rolling-03`, badge-tool task | 3 | Sound. | Resolved 3/3; `q=1.0`. | Ceiling. |
| `rolling-05`, original `durafmt` task | 3 | Sound. | Resolved 3/3. | Ceiling. |
| `rolling-06`, `logscan` task | 3 | Invalid: a hidden constraint was discovered when the live results were reviewed. | Resolved 1/3 before invalidation. | The intermediate-looking result cannot be used as evidence of model difficulty. |
| `salience-probe-v2`, `durafmt` with prominent requirement signposting removed | 3 | Sound. | Resolved 3/3; `q=1.0`. | Reducing requirement prominence did not create headroom on this task. |
| `low-salience-null-v3`, five tasks with requirements spread through ordinary project files | 15 | All five tasks passed the automated fairness checks. | Every task resolved 3/3; all 15 attempts resolved; `q=1.0` for each task. | Dispersing stated requirements did not create headroom in this cohort. |
| Phase 3 real-issue scout, `phase3-real-null-scout-v1` | 12 | Four tasks reconstructed from real project issues; all attempts were valid and all regression checks passed. | Four tasks, 3/3 resolved each; all 12 calls resolved with no replacements. Terminal result: `NO_HEADROOM_OBSERVED_IN_THIS_COHORT`. | No completion headroom was observed in this four-task cohort. This is not a population claim. |
| Operational-knowledge pilot, `pilot-signalnest-pager-v1` | 6 | One task, three bare calls and three instruction-file calls; all attempts were valid. | Both arms resolved 3/3. Each instruction-file call used about 40,000–60,000 more input tokens than a bare call (43,695–58,504 more; 150,120 more in total). Terminal result: `MECHANISM_NOT_SHOWN_IN_PILOT`. | On this task, both arms discovered the needed operating procedure within the limit, so the proposed completion mechanism was not shown. The token difference is descriptive evidence from six calls, not a general cost estimate. |

A planned fourth rolling candidate never reached a live model call, so it is not
an experimental cohort and does not appear as a result row. The detailed record
in `handoffs/PROCESS_FINDINGS_2026-08-19.md` explains the validity corrections and
the raw folders for the two newest experiments provide their complete evidence.
The two intervening salience studies are also summarized in the included
advisory essays; the requested raw-run scope for this package is limited to the
two newest experiments.

## 3. Two interpretations of the record

Neither position below is assumed to be correct. They agree on the observed
ceilings and disagree about what those ceilings mean.

| Position A | Position B (the project owner's position) |
|---|---|
| The test setup is limited to small repositories and gives a frontier coding model enough time and access to inspect them thoroughly. Within that setting, the model is effectively omniscient about any project fact that can fairly be discovered. If a needed fact cannot be discovered, withholding it makes the bare task unfair; if it can be discovered, this model finds it. Therefore no fair small task can depend on knowledge that the model will not recover, and the claim that an instruction file improves completion is not testable in this setup. | Many active projects elsewhere compare one repository instruction file against another and obtain signal. The underlying claim must therefore be testable, and something in this project's designs, test setup, or interpretation is wrong or mismatched to the claim. Candidate explanations include the chosen tasks, repository scale, runner limits, instruction treatments, outcome measures, or baseline. The current ceilings identify a problem to locate; they do not establish that the claim is untestable. |

## 4. Questions for the independent reviewer

1. Which position is right, and what evidence makes the difference?
2. What concrete experiment would be capable of falsifying Position A? Please
   specify the task source, repository scale, tested model, arms, time and token
   limits, outcomes, sample size, and decision rule.
3. How do comparable projects obtain signal? In particular, do they use
   different subject models, larger repositories, longer or shorter budgets,
   different outcomes such as cost, style, or preference, weaker baselines, or
   some other design feature?
4. What would you do next with this repository? Please distinguish work that is
   necessary to answer the scientific question from work that is merely useful
   engineering, and identify any stopping condition.

## 5. Archive inventory

- `HANDOFF-REVIEW.md`: this context, record, competing interpretations, questions,
  and inventory.
- `runs/dev-v2/phase3-real-null-scout-v1/`: the complete raw Phase 3 run,
  including the spending request and approval, event streams, final messages,
  diffs, checker output, attempt manifests, dispositions, and evidence ledger.
- `runs/dev-v2/pilot-signalnest-pager-v1/`: the complete raw two-arm pilot with
  the same categories of evidence.
- `tasks/real-boltons-indexed-slice/`, `tasks/real-cpython-doctest-notes/`,
  `tasks/real-cpython-enum-lookup/`, and `tasks/real-tomli-dotted-keys/`: the four
  complete real-issue tasks, including public projects, independent solutions,
  provenance, known-correct solutions, private tests, checks, requirement maps,
  source records, and file-hash manifests.
- `tasks/pilot-signalnest-pager/`: the complete operational-knowledge pilot task,
  including its mechanism definition, two deliberately wrong solutions, public
  project, independent solution and provenance, known-correct solution, check,
  requirements, and manifest.
- `controls/phase3/` and `controls/pilot/`: the Phase 3 construction-yield record
  and the pilot instruction file with its provenance. `controls/coder/null-m2.md`
  is the zero-byte bare-arm control referenced by the run requests.
- `TASK_TOOLING_V2_PLAN.md`, `handoffs/PROCESS_FINDINGS_2026-08-19.md`,
  `roadmap.md`, and `AGENTS.md`: the governing development specification, detailed
  experiment record, product roadmap, and repository rules.
- `md-eval-project-state-and-way-forward.md`,
  `failure-derived-md-eval-strategy.md`, and
  `how-coding-agent-mds-are-used-research-landscape.md`: three advisory essays
  offering product, strategy, and research context. They are included as views
  and background, not as experimental results.
- `tooling/` and `scripts/`: all current benchmark source code, tests, prompts,
  task import helpers, and run helpers.

The package intentionally excludes repository history, authentication or
credential files, older archive files, caches, and generated bytecode. Nothing
in the package is needed from an outside account or service to inspect the saved
tasks and evidence.
