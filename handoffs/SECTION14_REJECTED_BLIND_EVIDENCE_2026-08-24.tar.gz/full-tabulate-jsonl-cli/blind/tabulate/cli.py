"""Command-line interface for :mod:`tabulate`."""

from contextlib import nullcontext
import csv
import getopt
import json
import os
import re
import shlex
import sys
import textwrap

if __package__:
    from . import _DEFAULT_FLOATFMT, _DEFAULT_INTFMT, tabulate, tabulate_formats
else:  # Support ``python tabulate/cli.py`` from a source checkout.
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from tabulate import _DEFAULT_FLOATFMT, _DEFAULT_INTFMT, tabulate, tabulate_formats


READ_FORMATS = ("rsv", "csv", "jsonl")


def _split_headers(value):
    """Split a command-line header specification into individual fields."""
    if "," in value:
        try:
            return next(csv.reader([value], skipinitialspace=True))
        except csv.Error as exc:
            raise ValueError(f"invalid header list: {exc}") from exc
    return shlex.split(value)


def _parse_headers(value):
    """Translate a CLI header specification to a ``tabulate`` argument.

    Header keywords are passed through. JSON arrays and comma/space separated
    values become explicit column headings. JSON objects and ``key=heading``
    (or ``key:heading``) pairs become the key-remapping dictionary supported by
    :func:`tabulate` for records.
    """
    value = value.strip()
    if not value:
        return []
    if value in ("firstrow", "keys"):
        return value

    if value[0] in "[{":
        try:
            headers = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON header specification: {exc.msg}") from exc
        if isinstance(headers, list):
            return headers
        if isinstance(headers, dict):
            return headers
        raise ValueError("JSON headers must be an array or an object")

    fields = _split_headers(value)
    for delimiter in ("=", ":"):
        if fields and all(delimiter in field for field in fields):
            pairs = [field.split(delimiter, 1) for field in fields]
            if any(not key for key, _ in pairs):
                raise ValueError("header remapping keys must not be empty")
            return dict(pairs)
    return fields


def _read_rsv(fobject, sep):
    return [re.split(sep, row.rstrip()) for row in fobject if row.strip()]


def _read_csv(fobject, _sep):
    return list(csv.reader(fobject))


def _read_jsonl(fobject, _sep):
    return [json.loads(row) for row in fobject if row.strip()]


_readers = {
    "rsv": _read_rsv,
    "csv": _read_csv,
    "jsonl": _read_jsonl,
}


def _pprint_file(
    fobject,
    headers,
    tablefmt,
    sep,
    floatfmt,
    intfmt,
    file,
    colalign,
    readfmt="rsv",
):
    table = _readers[readfmt](fobject, sep)
    print(
        tabulate(
            table,
            headers,
            tablefmt,
            floatfmt=floatfmt,
            intfmt=intfmt,
            colalign=colalign,
        ),
        file=file,
    )


def main(argv=None):
    """\
    Usage: tabulate [options] [FILE ...]

    Pretty-print tabular data.
    See also https://github.com/astanin/python-tabulate

    FILE                      a filename of the file with tabular data;
                              if "-" or missing, read data from stdin.

    Options:

    -h, --help                show this message
    -1, --header              use the first row of data as a table header
    -H HEADERS, --headers HEADERS
                              set headers to "firstrow", "keys", a comma-separated
                              list, or key=heading pairs
    -o FILE, --output FILE    print table to FILE (default: stdout)
    -r FMT, --read FMT        read input as rsv, csv, or jsonl (default: rsv)
    -s REGEXP, --sep REGEXP   use a custom rsv column separator
                              (default: whitespace)
    -F FPFMT, --float FPFMT   floating point number format (default: g)
    -I INTFMT, --int INTFMT   integer point number format (default: "")
    -C ALIGN, --colalign ALIGN
                              column alignments separated by whitespace
    -f FMT, --format FMT      set output table format; supported formats:
                              plain, simple, github, grid, fancy_grid, pipe,
                              orgtbl, rst, mediawiki, html, latex, latex_raw,
                              latex_booktabs, latex_longtable, tsv
                              (default: simple)
    """
    usage = textwrap.dedent(main.__doc__)
    if argv is None:
        argv = sys.argv[1:]

    try:
        opts, args = getopt.getopt(
            argv,
            "h1H:o:r:s:F:I:C:f:",
            [
                "help",
                "header",
                "headers=",
                "output=",
                "read=",
                "sep=",
                "float=",
                "int=",
                "colalign=",
                "format=",
            ],
        )
    except getopt.GetoptError as exc:
        print(exc)
        print(usage)
        raise SystemExit(2) from exc

    headers = []
    floatfmt = _DEFAULT_FLOATFMT
    intfmt = _DEFAULT_INTFMT
    colalign = None
    tablefmt = "simple"
    readfmt = "rsv"
    sep = r"\s+"
    outfile = "-"

    for opt, value in opts:
        if opt in ("-1", "--header"):
            headers = "firstrow"
        elif opt in ("-H", "--headers"):
            try:
                headers = _parse_headers(value)
            except ValueError as exc:
                print(exc)
                print(usage)
                raise SystemExit(2) from exc
        elif opt in ("-o", "--output"):
            outfile = value
        elif opt in ("-r", "--read"):
            if value not in READ_FORMATS:
                print(f"{value} is not a supported input format")
                print(usage)
                raise SystemExit(3)
            readfmt = value
        elif opt in ("-F", "--float"):
            floatfmt = value
        elif opt in ("-I", "--int"):
            intfmt = value
        elif opt in ("-C", "--colalign"):
            colalign = value.split()
        elif opt in ("-f", "--format"):
            if value not in tabulate_formats:
                print(f"{value} is not a supported table format")
                print(usage)
                raise SystemExit(3)
            tablefmt = value
        elif opt in ("-s", "--sep"):
            sep = value
        elif opt in ("-h", "--help"):
            print(usage)
            raise SystemExit(0)

    files = ["-"] if not args else args
    output_context = nullcontext(sys.stdout) if outfile == "-" else open(outfile, "w")
    with output_context as out:
        for filename in files:
            input_context = (
                nullcontext(sys.stdin)
                if filename == "-"
                else open(filename, newline="" if readfmt == "csv" else None)
            )
            with input_context as fobject:
                _pprint_file(
                    fobject,
                    headers=headers,
                    tablefmt=tablefmt,
                    sep=sep,
                    floatfmt=floatfmt,
                    intfmt=intfmt,
                    file=out,
                    colalign=colalign,
                    readfmt=readfmt,
                )


_main = main


if __name__ == "__main__":
    main()
