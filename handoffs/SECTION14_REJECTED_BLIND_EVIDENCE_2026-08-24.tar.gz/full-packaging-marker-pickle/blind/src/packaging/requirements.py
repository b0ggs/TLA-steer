# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.
from __future__ import annotations

from typing import Iterator

from ._parser import parse_requirement as _parse_requirement
from ._tokenizer import ParserSyntaxError
from .markers import Marker, _is_valid_marker_list, _normalize_extra_values
from .specifiers import SpecifierSet
from .utils import canonicalize_name

__all__ = [
    "InvalidRequirement",
    "Requirement",
]


def __dir__() -> list[str]:
    return __all__


class InvalidRequirement(ValueError):
    """
    An invalid requirement was found, users should refer to PEP 508.
    """


class Requirement:
    """Parse a requirement.

    Parse a given requirement string into its parts, such as name, specifier,
    URL, and extras. Raises InvalidRequirement on a badly-formed requirement
    string.
    """

    # TODO: Can we test whether something is contained within a requirement?
    #       If so how do we do that? Do we need to test against the _name_ of
    #       the thing as well as the version? What about the markers?
    # TODO: Can we normalize the name and extra name?

    def __init__(self, requirement_string: str) -> None:
        try:
            parsed = _parse_requirement(requirement_string)
        except ParserSyntaxError as e:
            raise InvalidRequirement(str(e)) from e

        self.name: str = parsed.name
        self.url: str | None = parsed.url or None
        self.extras: set[str] = set(parsed.extras or [])
        self.specifier: SpecifierSet = SpecifierSet(parsed.specifier)
        self.marker: Marker | None = None
        if parsed.marker is not None:
            self.marker = Marker.__new__(Marker)
            self.marker._markers = _normalize_extra_values(parsed.marker)

    def _iter_parts(self, name: str) -> Iterator[str]:
        yield name

        if self.extras:
            formatted_extras = ",".join(sorted(self.extras))
            yield f"[{formatted_extras}]"

        if self.specifier:
            yield str(self.specifier)

        if self.url:
            yield f" @ {self.url}"
            if self.marker:
                yield " "

        if self.marker:
            yield f"; {self.marker}"

    def __str__(self) -> str:
        return "".join(self._iter_parts(self.name))

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}({str(self)!r})>"

    def __getstate__(
        self,
    ) -> tuple[str, str | None, set[str], SpecifierSet, Marker | None]:
        # Preserve the components directly.  Re-parsing str(self) would lose
        # marker values whose quote characters cannot be represented by the
        # marker formatter.
        return (self.name, self.url, self.extras, self.specifier, self.marker)

    def __setstate__(self, state: object) -> None:
        if isinstance(state, tuple) and len(state) == 5:
            # Current format: (name, url, extras, specifier, marker)
            name, url, extras, specifier, marker = state
        else:
            legacy_state: dict[object, object]
            if isinstance(state, dict):
                # packaging 25.0-26.1 used a normal instance dictionary.
                legacy_state = state
            elif (
                isinstance(state, tuple)
                and len(state) == 2
                and state[0] is None
                and isinstance(state[1], dict)
            ):
                # Also accept the automatic slots layout, used by development
                # versions which briefly made Requirement slotted.
                legacy_state = state[1]
            else:
                raise TypeError("Cannot restore Requirement from serialized state")

            required_keys = {"name", "url", "extras", "specifier", "marker"}
            if set(legacy_state) != required_keys:
                raise TypeError("Cannot restore Requirement from serialized state")

            name = legacy_state["name"]
            url = legacy_state["url"]
            extras = legacy_state["extras"]
            specifier = legacy_state["specifier"]
            marker = legacy_state["marker"]

        if not (
            isinstance(name, str)
            and (url is None or isinstance(url, str))
            and isinstance(extras, set)
            and all(isinstance(extra, str) for extra in extras)
            and isinstance(specifier, SpecifierSet)
            and (marker is None or isinstance(marker, Marker))
        ):
            raise TypeError("Cannot restore Requirement from serialized state")

        # Reject nested objects which have the right class but contain invalid
        # or only partially initialized state.
        try:
            specifier_check = SpecifierSet.__new__(SpecifierSet)
            specifier_check.__setstate__(specifier.__getstate__())
            marker_is_valid = marker is None or _is_valid_marker_list(marker._markers)
        except (AttributeError, TypeError, ValueError):
            raise TypeError(
                "Cannot restore Requirement from serialized state"
            ) from None
        if not marker_is_valid:
            raise TypeError("Cannot restore Requirement from serialized state")

        # Assign only after the complete state has been validated.
        self.name = name
        self.url = url
        self.extras = extras
        self.specifier = specifier
        self.marker = marker

    def __hash__(self) -> int:
        return hash(tuple(self._iter_parts(canonicalize_name(self.name))))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Requirement):
            return NotImplemented

        return (
            canonicalize_name(self.name) == canonicalize_name(other.name)
            and self.extras == other.extras
            and self.specifier == other.specifier
            and self.url == other.url
            and self.marker == other.marker
        )
