# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

import os

# -- Project information loading ----------------------------------------------

ABOUT = {}
_BASE_DIR = os.path.join(os.path.dirname(__file__), os.pardir)
with open(os.path.join(_BASE_DIR, "src", "packaging", "__init__.py")) as f:
    exec(f.read(), ABOUT)

# -- General configuration ----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

# Add any Sphinx extension module names here, as strings. They can be
# extensions  coming with Sphinx (named 'sphinx.ext.*') or your custom ones.
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.doctest",
    "sphinx.ext.extlinks",
    "sphinx.ext.intersphinx",
]

# General information about the project.
project = "Packaging"
version = ABOUT["__version__"]
release = ABOUT["__version__"]
copyright = ABOUT["__copyright__"]

# -- Options for HTML output --------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.

html_theme = "furo"
html_title = project

html_theme_options = {
    "source_repository": "https://github.com/pypa/packaging",
    "source_branch": "main",
    "source_directory": "docs/",
    "footer_icons": [
        {
            "name": "GitHub",
            "url": "https://github.com/pypa/packaging",
            "html": """
                <svg stroke="currentColor" fill="currentColor" stroke-width="0"
                viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54
                    2.29 6.53 5.47 7.59.4.07.55-.17.55-.38
                    0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01
                    1.08.58 1.23.82.72 1.21 1.87.87
                    2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95
                    0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21
                    2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04
                    2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82
                    2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0
                    1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0
                    16 8c0-4.42-3.58-8-8-8z"></path>
                </svg>
            """,
            "class": "",
        },
    ],
}
html_copy_source = False
html_show_sourcelink = False

# -- Options for autodoc ----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/extensions/autodoc.html#configuration

autodoc_member_order = "bysource"
autodoc_preserve_defaults = True
autodoc_default_options = {
    "exclude-members": "__weakref__",
}

# Allow the signature to be overridden
autodoc_docstring_signature = True

# Automatically extract typehints when specified and place them in
# descriptions of the relevant function/method.
autodoc_typehints = "description"

# Don't show class signature with the class' name.
autodoc_class_signature = "separated"

# Rewrite bare ``Path`` in rendered annotations to the stdlib target so
# intersphinx resolves it (annotations are strings under
# ``from __future__ import annotations``).
autodoc_type_aliases = {
    "Path": "pathlib.Path",
}

# -- Options for extlinks -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/extensions/extlinks.html#configuration

extlinks = {
    "issue": ("https://github.com/pypa/packaging/issues/%s", "#%s"),
    "pull": ("https://github.com/pypa/packaging/pull/%s", "PR #%s"),
}

# -- Options for intersphinx ----------------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/extensions/intersphinx.html#configuration

intersphinx_mapping = {
    "python": ("https://docs.python.org/3/", None),
    "pypug": ("https://packaging.python.org/", None),
}

# -- Options for nitpicky mode ------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#confval-nitpick_ignore

# Built with ``-n`` so unresolved cross-references fail the build. These
# targets have no documentation page on purpose, so they are allowed to
# stay unresolved: private internal types, and TypeVars / type aliases the
# Python domain cannot resolve as classes.
nitpick_ignore = [
    ("py:class", "packaging.version._BaseVersion"),
    ("py:class", "_Validator"),
    ("py:class", "_MetadataVersion"),
    ("py:class", "_VersionReplace"),
    ("py:class", "T"),
    ("py:class", "_T"),
    ("py:class", "packaging.specifiers.T"),
    ("py:class", "UnparsedVersion"),
    ("py:class", "UnparsedVersionVar"),
]
