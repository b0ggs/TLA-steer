"""Async wrapper around :class:`ReadWriteLock` for use with ``asyncio``."""

from __future__ import annotations

import asyncio
import functools
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from ._api import ContextErrorPolicy, _raise_body_and_release, _resolve_context_error_policy
from ._read_write import ReadWriteLock

if TYPE_CHECKING:
    import os
    from collections.abc import AsyncGenerator, Callable
    from concurrent import futures
    from types import TracebackType


class AsyncReadWriteLock:
    """
    Async wrapper around :class:`ReadWriteLock` for use in ``asyncio`` applications.

    This wrapper dispatches every blocking SQLite operation to a thread pool via ``loop.run_in_executor()`` because
    Python's :mod:`sqlite3` module has no async API. It delegates reentrancy, upgrade/downgrade rules, and singleton
    behavior to the underlying :class:`ReadWriteLock`.

    :param lock_file: path to the SQLite database file used as the lock
    :param timeout: maximum wait time in seconds; ``-1`` means block indefinitely
    :param blocking: if ``False``, raise :class:`~filelock.Timeout` immediately when the lock is unavailable
    :param is_singleton: if ``True``, reuse existing :class:`ReadWriteLock` instances for the same resolved path
    :param loop: event loop for ``run_in_executor``; ``None`` uses the running loop
    :param executor: executor for ``run_in_executor``. When ``None`` this lock creates and owns a dedicated
        single-thread executor so every operation runs on the same thread (SQLite affinity requires this) and shuts it
        down in :meth:`close`. This lock uses a caller-supplied executor as-is and never shuts it down, so after passing
        no executor call :meth:`close` to release the owned one.
    :param context_error_policy: how simultaneous caller cancellation/body failure and backend cleanup failure are
        surfaced: ``"chain"`` uses exception context and ``"group"`` raises a :class:`BaseExceptionGroup`

    .. versionadded:: 3.21.0

    """

    def __init__(  # noqa: PLR0913
        self,
        lock_file: str | os.PathLike[str],
        timeout: float = -1,
        *,
        blocking: bool = True,
        is_singleton: bool = True,
        loop: asyncio.AbstractEventLoop | None = None,
        executor: futures.Executor | None = None,
        context_error_policy: ContextErrorPolicy = "chain",
    ) -> None:
        self._lock = ReadWriteLock(lock_file, timeout, blocking=blocking, is_singleton=is_singleton)
        self._loop = loop
        self._owns_executor = executor is None
        self._executor = executor or ThreadPoolExecutor(max_workers=1)
        self._context_error_policy = _resolve_context_error_policy(context_error_policy)
        self._transition_lock = asyncio.Lock()
        self._executor_shutdown = False

    @property
    def lock_file(self) -> str:
        """The path to the lock file."""
        return self._lock.lock_file

    @property
    def timeout(self) -> float:
        """The default timeout."""
        return self._lock.timeout

    @property
    def blocking(self) -> bool:
        """Whether blocking is enabled by default."""
        return self._lock.blocking

    @property
    def loop(self) -> asyncio.AbstractEventLoop | None:
        """The event loop (or ``None`` for the running loop)."""
        return self._loop

    @property
    def executor(self) -> futures.Executor:
        """The executor used for ``run_in_executor`` (a dedicated single-thread one if none was supplied)."""
        return self._executor

    @property
    def context_error_policy(self) -> ContextErrorPolicy:
        """How simultaneous context-body/cancellation and backend cleanup errors are surfaced."""
        return self._context_error_policy

    @asynccontextmanager
    async def read_lock(self, timeout: float | None = None, *, blocking: bool | None = None) -> AsyncGenerator[None]:
        """
        Async context manager that acquires and releases a shared read lock.

        Falls back to instance defaults for *timeout* and *blocking* when ``None``.

        :param timeout: maximum wait time in seconds, or ``None`` to use the instance default
        :param blocking: if ``False``, raise :class:`~filelock.Timeout` immediately; ``None`` uses the instance default

        """
        if timeout is None:
            timeout = self._lock.timeout
        if blocking is None:
            blocking = self._lock.blocking
        await self.acquire_read(timeout, blocking=blocking)
        try:
            yield
        except BaseException as body_error:
            await self._release_in_context(body_error)
            raise
        else:
            await self.release()

    @asynccontextmanager
    async def write_lock(self, timeout: float | None = None, *, blocking: bool | None = None) -> AsyncGenerator[None]:
        """
        Async context manager that acquires and releases an exclusive write lock.

        Falls back to instance defaults for *timeout* and *blocking* when ``None``.

        :param timeout: maximum wait time in seconds, or ``None`` to use the instance default
        :param blocking: if ``False``, raise :class:`~filelock.Timeout` immediately; ``None`` uses the instance default

        """
        if timeout is None:
            timeout = self._lock.timeout
        if blocking is None:
            blocking = self._lock.blocking
        await self.acquire_write(timeout, blocking=blocking)
        try:
            yield
        except BaseException as body_error:
            await self._release_in_context(body_error)
            raise
        else:
            await self.release()

    async def acquire_read(self, timeout: float = -1, *, blocking: bool = True) -> AsyncAcquireReadWriteReturnProxy:
        """
        Acquire a shared read lock.

        See :meth:`ReadWriteLock.acquire_read` for full semantics.

        :param timeout: maximum wait time in seconds; ``-1`` means block indefinitely
        :param blocking: if ``False``, raise :class:`~filelock.Timeout` immediately when the lock is unavailable

        :returns: a proxy that can be used as an async context manager to release the lock

        :raises RuntimeError: if a write lock is already held on this instance
        :raises Timeout: if the lock cannot be acquired within *timeout* seconds

        """
        async with self._transition_lock:
            await self._run_acquire(self._lock.acquire_read, timeout, blocking=blocking)
        return AsyncAcquireReadWriteReturnProxy(lock=self)

    async def acquire_write(self, timeout: float = -1, *, blocking: bool = True) -> AsyncAcquireReadWriteReturnProxy:
        """
        Acquire an exclusive write lock.

        See :meth:`ReadWriteLock.acquire_write` for full semantics.

        :param timeout: maximum wait time in seconds; ``-1`` means block indefinitely
        :param blocking: if ``False``, raise :class:`~filelock.Timeout` immediately when the lock is unavailable

        :returns: a proxy that can be used as an async context manager to release the lock

        :raises RuntimeError: if a read lock is already held, or a write lock is held by a different thread
        :raises Timeout: if the lock cannot be acquired within *timeout* seconds

        """
        async with self._transition_lock:
            await self._run_acquire(self._lock.acquire_write, timeout, blocking=blocking)
        return AsyncAcquireReadWriteReturnProxy(lock=self)

    async def release(self, *, force: bool = False) -> None:
        """
        Release one level of the current lock.

        See :meth:`ReadWriteLock.release` for full semantics.

        :param force: if ``True``, release the lock completely regardless of the current lock level

        :raises RuntimeError: if no lock is currently held and *force* is ``False``

        """
        async with self._transition_lock:
            await self._run(self._lock.release, force=force)

    async def close(self) -> None:
        """
        Release the lock (if held) and close the underlying SQLite connection.

        After calling this method, the lock instance is no longer usable.

        """
        async with self._transition_lock:
            await self._run(self._lock.close, on_success=self._shutdown_owned_executor)

    async def _run_acquire(self, func: Callable[..., object], *args: object, **kwargs: object) -> object:
        """Run an acquire and remove its exact claim if its awaiting caller is cancelled."""
        future = self._submit(func, *args, **kwargs)
        try:
            return await asyncio.shield(future)
        except asyncio.CancelledError as cancellation:
            await self._drain_future(future)
            try:
                future.result()
            except BaseException as backend_error:
                self._raise_cancellation_and_backend_error(cancellation, backend_error)

            # The acquire completed after cancellation.  The transition lock prevents another caller from changing
            # the recursion level before this one-level rollback removes only the cancelled caller's claim.
            rollback = self._submit(self._lock.release)
            await self._drain_future(rollback)
            try:
                rollback.result()
            except BaseException as rollback_error:
                self._raise_cancellation_and_backend_error(cancellation, rollback_error)
            raise

    async def _run(
        self,
        func: Callable[..., object],
        *args: object,
        on_success: Callable[[], None] | None = None,
        **kwargs: object,
    ) -> object:
        """Run backend work to completion, even if its caller is cancelled while awaiting it."""
        future = self._submit(func, *args, **kwargs)
        try:
            result = await asyncio.shield(future)
        except asyncio.CancelledError as cancellation:
            await self._drain_future(future)
            try:
                result = future.result()
            except BaseException as backend_error:
                self._raise_cancellation_and_backend_error(cancellation, backend_error)
            if on_success is not None:
                on_success()
            raise
        if on_success is not None:
            on_success()
        return result

    def _submit(self, func: Callable[..., object], *args: object, **kwargs: object) -> asyncio.Future[object]:
        loop = self._loop or asyncio.get_running_loop()
        return loop.run_in_executor(self._executor, functools.partial(func, *args, **kwargs))

    @staticmethod
    async def _drain_future(future: asyncio.Future[object]) -> None:
        while not future.done():
            try:
                await asyncio.shield(future)
            except BaseException:
                pass

    def _raise_cancellation_and_backend_error(
        self, cancellation: asyncio.CancelledError, backend_error: BaseException
    ) -> None:
        if self._context_error_policy == "group":
            _raise_body_and_release(cancellation, backend_error)
        raise backend_error

    async def _release_in_context(self, body_error: BaseException | None) -> None:
        try:
            await self.release()
        except BaseException as release_error:
            if body_error is None or self._context_error_policy == "chain":
                raise
            _raise_body_and_release(body_error, release_error)

    def _shutdown_owned_executor(self) -> None:
        if self._owns_executor and not self._executor_shutdown:
            self._executor.shutdown(wait=False)
            self._executor_shutdown = True

    def __del__(self) -> None:
        # Safety net when close() was never called: shut down the executor we own so its worker thread does not
        # outlive the lock. shutdown(wait=False) never blocks.
        if getattr(self, "_owns_executor", False) and not getattr(self, "_executor_shutdown", False):
            self._executor.shutdown(wait=False)


class AsyncAcquireReadWriteReturnProxy:
    """Context-aware object that releases the async read/write lock on exit."""

    def __init__(self, lock: AsyncReadWriteLock) -> None:
        self.lock = lock

    async def __aenter__(self) -> AsyncReadWriteLock:
        return self.lock

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.lock._release_in_context(exc_value)  # noqa: SLF001


__all__ = [
    "AsyncAcquireReadWriteReturnProxy",
    "AsyncReadWriteLock",
]
