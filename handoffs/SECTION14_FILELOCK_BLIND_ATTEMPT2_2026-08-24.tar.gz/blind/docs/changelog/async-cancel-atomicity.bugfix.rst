Make executor-backed async acquisition, release, close, and read/write rollback cancellation-atomic, preserving both
caller cancellation and backend cleanup failures while keeping failed rollback state retryable.
