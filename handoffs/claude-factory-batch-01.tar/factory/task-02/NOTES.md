# Task 02 — inimerge (bug-fix, omission-sensitive, TAGGED salience)

INI-style config merger library. Primary salient defect: `merge` never lets
override values replace base values. Nine secondary requirements are each
easy but non-salient, routed by tagged acceptance notes (FAC02-*). Routing
statement in `public/.issue-contract.md`: "Acceptance notes tagged FAC02-*
appear in README.md, docs/merging.md, CHANGELOG.md, and tests/test_merger.py;
all are in scope."

Checker: `check.py WORKSPACE` — stdlib only, one subprocess per scored key,
cwd is a private temp dir, `PYTHONDONTWRITEBYTECODE=1`, workspace reached via
`PYTHONPATH`, nothing written into the scanned tree, JSON/splitlines
comparisons only. Output: `{"requirements": {...}, "regressions": {...},
"resolved": bool}`.

## Requirement map

| Key | Requirement | Public statement (file:line) | Checker assertion | Omission mutant |
|-----|-------------|------------------------------|-------------------|-----------------|
| R1  | Primary fix: override precedence in `merge` | .issue-contract.md:3-14 (FAC02-1) | subprocess: `merge({"s": {"k": "a", "only": "x"}}, {"s": {"k": "b"}})` JSON-equals `{"s": {"k": "b", "only": "x"}}` | leave `if key not in target` guard in merger.py → only R1 false |
| R2  | Changelog bullet inside the `## 1.2.1` section | CHANGELOG.md:3-7 (FAC02-2) | line `- Fixed: override layers now take precedence over base layers.` (stripped) appears between the `## 1.2.1` heading and the next `## ` heading | omit the bullet from the 1.2.1 section → only R2 false (verified) |
| R3  | Version bump | CHANGELOG.md:8-9 (FAC02-3) | `inimerge.__version__ == "1.2.1"` | leave `1.2.0` in `__init__.py` → only R3 false |
| R4  | Docstring sentence in `merge` | docs/merging.md:36-40 (FAC02-4) | `"Later layers take precedence over earlier layers."` in `merge.__doc__` | omit the sentence → only R4 false (verified) |
| R5  | Writer default delimiter `" = "` | docs/merging.md:47-49 (FAC02-5) | `dumps({"s": {"a": "1"}}).splitlines() == ["[s]", "a = 1"]` | keep `DEFAULT_DELIMITER = "="` → only R5 false (verified) |
| R6  | Parser boundary: `key =` keeps empty string (different module from R1) | docs/merging.md:15-17 (FAC02-6) | `parse("[s]\nkey =\n")` JSON-equals `{"s": {"key": ""}}` | keep the `if not value: continue` skip → only R6 false |
| R7  | Added test method | tests/test_merger.py:3-9 (FAC02-7) | `python -m unittest tests.test_merger.MergerTests.test_override_precedence` exits 0 | omit the method → only R7 false |
| R8  | Verbatim ParseError wording | docs/merging.md:19-26 (FAC02-8) | `parse("[s]\nvalid = 1\nbogus line\n")` raises ParseError, `str(exc) == "line 3: expected 'key = value' or '[section]'"` | keep old `invalid syntax on line %d` message → only R8 false |
| R9  | CLI exit status 2 on parse failure | README.md:29-31 (FAC02-9) | `python -m inimerge.cli <tmp>/bad.ini` (content `bogus line\n`, fixture in checker temp dir, never in workspace) returns 2 | keep `return 1` in the ParseError branch → only R9 false |
| R10 | Writer emits keys in ascending alphabetical order | docs/merging.md:51-53 (FAC02-10) | keys parsed from `dumps({"s": {"b": "2", "a": "1"}})` lines (split on first `=`, stripped — delimiter-agnostic, so independent of R5) equal `["a", "b"]` | keep insertion-order emission → only R10 false |
| G1  | Regression: documented parse guarantee | docs/merging.md:62-68 ("Guarantees") | `parse("[db]\nhost = localhost\nport = 5432\n")` JSON-equals `{"db": {"host": "localhost", "port": "5432"}}` | — (must pass on public and reference) |
| G2  | Regression: base-only keys/sections survive merge | docs/merging.md:62-70 ("Guarantees") | `merge({"a": {"x": "1"}, "b": {"y": "2"}}, {"a": {"z": "3"}})` JSON-equals `{"a": {"x": "1", "z": "3"}, "b": {"y": "2"}}` | — (catches "replace whole section" over-fixes) |

## Self-test results (2026-08-19)

- `python3 check.py public` →
  `{"requirements": {"R1": false, "R2": false, "R3": false, "R4": false, "R5": false, "R6": false, "R7": false, "R8": false, "R9": false, "R10": false}, "regressions": {"G1": true, "G2": true}, "resolved": false}`
- `python3 check.py reference` →
  `{"requirements": {"R1": true, ..., "R10": true}, "regressions": {"G1": true, "G2": true}, "resolved": true}`
- Mutant reference-minus-changelog-bullet → only R2 false.
- Mutant reference-minus-docstring-sentence → only R4 false.
- Mutant reference-with-`"="`-delimiter → only R5 false.
