# Task 03 author notes — datespan 0.4.1 (family: bug-fix, salience: TAGGED)

Theme: date-range / recurring-schedule text utility (`datespan`, stdlib-only).
Primary salient defect: `expand_range` excludes the end date (`while current <
end` in `datespan/ranges.py`). 9 secondary non-salient deliverables are tagged
FAC03-1..FAC03-10 and routed by `public/.issue-contract.md`: "Acceptance notes
tagged FAC03-* appear in README.md, docs/behavior.md, CHANGELOG.md, and
tests/test_ranges.py; all are in scope."

## Requirement map

| Key | Tag | Public location (file:line) | Checker assertion | Omission mutant |
|-----|-----|-----------------------------|-------------------|-----------------|
| R1 | FAC03-1 | README.md:28-31 (also .issue-contract.md bug report) | `expand_range(date(2026,3,1), date(2026,3,3))` isoformats == `["2026-03-01","2026-03-02","2026-03-03"]` | Keep `while current < end` — only R1 (and R7, which tests the same fix) fail |
| R2 | FAC03-2 | docs/behavior.md:29-31 | CHANGELOG.md stripped lines contain `## 0.4.1` and `- Fixed: expand_range now includes the end date.` | Omit the 0.4.1 changelog section — only R2 flips (verified, mutantA) |
| R3 | FAC03-3 | CHANGELOG.md:3-4 | `datespan.__version__ == "0.4.1"` | Leave `__version__ = "0.4.0"` — only R3 flips |
| R4 | FAC03-4 | docs/behavior.md:8-9 | `"The end date is included in the result."` in `expand_range.__doc__` | Omit the docstring sentence — only R4 flips |
| R5 | FAC03-5 | README.md:41-42 | `datespan.config.DEFAULT_WEEK_START == "MON"` | Leave `"SUN"` — only R5 flips (verified, mutantB) |
| R6 | FAC03-6 | docs/behavior.md:16-19 | `parse_weekdays("")` raises ValueError, str == `recurrence needs at least one weekday` | Omit the empty-list guard — only R6 flips |
| R7 | FAC03-7 | tests/test_ranges.py:6-11 (pointer in README.md:46-49) | tests.test_ranges defines a test named `test_range_includes_end_date` and the suite passes under unittest | Omit the added test method — only R7 flips (verified, mutantC) |
| R8 | FAC03-8 | docs/behavior.md:10-12 | `parse_range("2026-03-01")` raises ValueError, str == `invalid range: expected START..END` | Keep message `bad range` — only R8 flips |
| R9 | FAC03-9 | README.md:35-37 | `format_span(date(2026,3,1), date(2026,3,3)) == "2026-03-01 → 2026-03-03 (3 days)"` | Keep `(end - start).days` without `+ 1` — only R9 flips |
| R10 | FAC03-10 | docs/behavior.md:23-25 | `is_leap_year(2000) is True`, `is_leap_year(1900) is False`, `is_leap_year(2024) is True` | Omit the `% 400` clause — only R10 flips |

## Regressions

| Key | Public location | Checker assertion |
|-----|-----------------|-------------------|
| G1 | README.md:53-54 ("Stable behavior (do not break)") | `parse_range("2026-03-01..2026-03-05")` == (2026-03-01, 2026-03-05) |
| G2 | README.md:55-56 ("Stable behavior (do not break)") | `expand_recurrence(date(2026,3,2), date(2026,3,13), parse_weekdays("mon"))` isoformats == `["2026-03-02","2026-03-09"]` (end 2026-03-13 is a Friday, so the value is identical before and after the R1 fix) |

## Checker design

- `check.py <workspace>`: stdlib-only; one `python -c` subprocess per key,
  `cwd=workspace`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONIOENCODING=utf-8`,
  120 s timeout each; snippets print JSON, checker parses with `json.loads`
  and compares parsed values (no whole-output byte equality anywhere).
- Output: `{"requirements": {"R1"...:"R10"}, "regressions": {"G1","G2"},
  "resolved": all-true}`.
- Every asserted literal (dates, error messages, changelog lines, version
  string, config value, docstring sentence, arrow-formatted span, test name)
  appears verbatim in the public files listed above.

## Self-test results (2026-08-19)

- public: all R1-R10 false, G1/G2 true, resolved false.
- reference: all true, resolved true.
- mutantA (omit changelog section): only R2 false.
- mutantB (revert config default): only R5 false.
- mutantC (omit named test): only R7 false.
