# Task 06 author notes — recval `summarize` (feature-addition, TAGGED salience)

Routing: `public/.issue-contract.md` states "Acceptance notes tagged
FAC06-* appear in README.md, docs/cli.md, CHANGELOG.md, examples/; all
are in scope." Every asserted value below is stated verbatim in the
cited public file. Notes are placed in a different file than the one the
checker inspects whenever the note quotes a literal the checker greps
for (FAC06-7, FAC06-8), so the note text cannot self-satisfy the check.

## Requirement traceability

| Req | Tag | Public location | Checker assertion (check.py) | Omission mutant |
|-----|-----|-----------------|------------------------------|-----------------|
| R1 | FAC06-1 | docs/cli.md:47-52 | `python -m recval summarize examples/rules.json examples/records.jsonl` exits 0; stdout parses as a JSON object with exactly keys {total, valid, invalid, errors_by_field} | Coder never adds the subcommand at all (argparse rejects it, exit 2) |
| R2 | FAC06-2 | docs/cli.md:53-69 | Parsed stdout of the same command == {"total":6,"valid":4,"invalid":2,"errors_by_field":{"age":1,"name":1}} (semantic json.loads compare, no byte equality) | Coder forgets errors_by_field aggregation (or miscounts), keys/counts drift |
| R3 | FAC06-3 | docs/cli.md:70-72 | `summarize --help` exits 0 and stdout contains verbatim "Summarize validation results as machine-readable JSON counts." | Coder writes their own help blurb instead of the documented sentence |
| R4 | FAC06-4 | docs/cli.md:73-75 | Nonexistent records path (checker tempdir, absolute) -> exit 2, stderr contains "error: records file not found:" and the path | Coder lets FileNotFoundError traceback escape (exit 1, no message) |
| R5 | FAC06-5 | README.md:38-44 | Zero-byte records file (created in checker tempdir) -> exit 0 and parsed stdout == {"total":0,"valid":0,"invalid":0,"errors_by_field":{}} | Coder skips the loader.py change; public loader raises LoaderError on empty input |
| R6 | FAC06-6 | examples/README.md:9-12 | examples/summary.json parses (json.loads) to the same object as R2 | Coder forgets to add the example file |
| R7 | FAC06-7 | README.md:45-46 (note NOT in CHANGELOG, so it cannot self-match) | CHANGELOG.md contains "## 0.3.0" and "- Added the summarize subcommand." | Coder skips the changelog entry (verified as mutant B) |
| R8 | FAC06-8 | docs/cli.md:76-77 (note NOT in README, so it cannot self-match) | README.md contains "Default summary indent: 2 spaces." | Coder skips the README defaults line |
| R9 | FAC06-9 | CHANGELOG.md:5-7 (Unreleased note) | `python -m recval --version` exits 0, stdout.strip() == "recval 0.3.0" | Coder forgets the version bump (public still 0.2.0) |
| R10 | FAC06-10 | README.md:47-49 | tests/test_summarize.py exists; `python -m unittest discover -s tests -v` (cwd=workspace) exits 0 and its output mentions "test_summarize" | Coder skips the new test (suite passes but never mentions test_summarize) |

## Regressions

| Key | Public location | Checker assertion |
|-----|-----------------|-------------------|
| G1 | docs/cli.md:9-40 (format, exit codes, and exact example transcript) | `validate examples/rules.json examples/records.jsonl` exits 1; stdout contains "record 3: name: missing required key" and "record 5: age: out of range 0..130" |
| G2 | docs/cli.md:23-30 | `validate examples/rules.json examples/valid_only.jsonl` exits 0; stdout.strip() == "ok" |

## Checker hygiene

- stdlib only; workspace path is argv[1]; check.py lives outside the tree.
- One fresh subprocess per behavioural requirement (R1-R5, R9, R10, G1,
  G2), cwd=workspace, PYTHONDONTWRITEBYTECODE=1; file-content
  requirements (R6-R8) are plain reads. Nothing is written into the
  workspace (verified: zero __pycache__/*.pyc after runs). Temp inputs
  (missing path, empty file) live in checker-owned tempdirs.
- All JSON comparisons are parsed/semantic; string checks are exact
  literals quoted verbatim in public docs. Timeout 120 s per subprocess.

## Self-test results (2026-08-19)

- public: requirements all false, regressions all true, resolved false.
- reference: all true, resolved true.
- mutant A (revert loader empty-file handling): only R5 false.
- mutant B (delete CHANGELOG 0.3.0 section): only R7 false.
