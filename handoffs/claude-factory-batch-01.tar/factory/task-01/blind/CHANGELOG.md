# Changelog

## Unreleased

## 0.4.1

- Fixed: median now averages the two middle values for even-sized columns

## 0.4.0

- Added JSON summary output with configurable precision
- Added --version flag

## 0.3.0

- Initial public release of the stats command
