# NOTES — task-01 (bug-fix, TAGGED salience): colstat median fix

Family: bug-fix. Theme: CSV column-statistics tool (`colstat`, stdlib only).
Primary defect: `colstat.stats.median` returns the upper middle value for
even-sized inputs instead of averaging the two middle values.
Salience mode: TAGGED — every acceptance note carries a FAC01-n tag;
`public/.issue-contract.md` (lines 12-15) routes: notes tagged FAC01-* appear
in README.md, docs/algorithms.md, CHANGELOG.md, tests/test_stats.py; all in
scope.

## Requirement map

| Req | What must change | Public source (file:line) | Checker assertion (one subprocess each unless noted) | Omission mutant (flips only this key) |
|-----|------------------|---------------------------|------------------------------------------------------|----------------------------------------|
| R1  | Fix even-count median in `colstat/stats.py` | docs/algorithms.md:10-15 (FAC01-1); .issue-contract.md:4-8 | `python -c` import `median`; `median([1.0, 2.0, 3.0, 4.0])` == 2.5 (float-parsed, 1e-9 tol) | Keep buggy `ordered[n // 2]`; only R1 false (G2 odd case still passes) |
| R2  | Version bump in `colstat/__init__.py` | README.md:17-18 (FAC01-2) | `python -c` prints `colstat.__version__`; stripped stdout == `0.4.1` | Leave `__version__ = "0.4.0"`; only R2 false (R9 reads CLI output; reference CLI derives from `__version__`, but a coder hardcoding the CLI string still passes R9 independently) |
| R3  | CHANGELOG section for 0.4.1 | CHANGELOG.md:5-7 (FAC01-3, heading and bullet given verbatim in backticks) | Parse CHANGELOG.md `splitlines()`, stripped; must contain line `## 0.4.1` and line `- Fixed: median now averages the two middle values for even-sized columns` (no subprocess; pure text parse). Backticked note lines cannot false-positive | Delete the `## 0.4.1` section; only R3 flips (verified) |
| R4  | Docstring line in `median` | docs/algorithms.md:17-20 (FAC01-4, line given verbatim) | `python -c` prints `median.__doc__`; must contain `Returns the mean of the two middle values when n is even.` | Remove the docstring line; only R4 flips (verified) |
| R5  | Config default in `colstat/config.py` | docs/algorithms.md:29-30 (FAC01-5) | `python -c` prints `DEFAULT_PRECISION`; stripped stdout == `4` | Revert to `6`; only R5 flips (verified) |
| R6  | Boundary case in a DIFFERENT module (`colstat/reader.py`) | docs/algorithms.md:34-36 (FAC01-6, message given verbatim) | Subprocess writes header-only CSV into checker temp dir, calls `load_rows`; stdout must be `VALUEERROR:no data rows in input` | Omit the `len(rows) < 2` guard; only R6 false (nothing else feeds empty input) |
| R7  | Added test in `tests/test_stats.py` | tests/test_stats.py:7-10 (FAC01-7); README.md:37-41 | Source of tests/test_stats.py contains `def test_median_even_count` AND `python -m unittest discover -s <ws>/tests -t <ws>` exits 0 (one subprocess + one file read) | Omit the new test method; suite still passes but name absent, only R7 false |
| R8  | CLI unknown-column wording + exit status | README.md:27-34 (FAC01-8, exact stderr line for `nosuchcol` given verbatim) | `python -m colstat.cli stats <ws>/examples/scores.csv nosuchcol`; exit code == 2 and stripped stderr == `colstat: unknown column: nosuchcol` | Keep old `error: no such column:` / exit 1; only R8 false |
| R9  | `--version` output | README.md:20-24 (FAC01-9, exact stdout line given verbatim) | `python -m colstat.cli --version`; exit 0 and stripped stdout == `colstat 0.4.1` | Keep hardcoded `colstat 0.4.0` print; only R9 false (R2 checks the module attr, independent) |
| R10 | JSON key order in `column_summary` output | docs/algorithms.md:40-42 (FAC01-10) | `python -m colstat.cli stats <ws>/examples/scores.csv score`; `json.loads(..., object_pairs_hook=list)` key order == `["count","min","max","mean","median","stdev"]` | Keep old `count, mean, min, max, ...` ordering; only R10 false (values not byte-compared) |

## Regressions

| Key | Guarded behavior | Public source | Assertion |
|-----|------------------|---------------|-----------|
| G1  | mean unchanged | docs/algorithms.md:4-6 (documented example) | `mean([2.0, 4.0, 9.0])` == 5.0 |
| G2  | odd-count median unchanged | docs/algorithms.md:10-12 (documented example) | `median([5.0, 1.0, 9.0])` == 5.0 |

Both pass on public/ (bug affects even counts only) and on reference/.

## Checker hygiene

- stdlib only; workspace path from argv[1]; every subprocess runs with
  cwd = checker-private temp dir, `PYTHONDONTWRITEBYTECODE=1`,
  `PYTHONPATH=<workspace>`; nothing written into the scanned tree
  (verified: zero `__pycache__`/`.pyc` after runs).
- Semantic comparisons only: float parse with tolerance (R1, G1, G2),
  stripped-line equality (R2, R5, R8, R9), `splitlines` line membership
  (R3), substring of live `__doc__` (R4), parsed exception message (R6),
  exit-code + name grep (R7), `json.loads` with `object_pairs_hook` (R10).
  No whole-output byte equality anywhere except single lines whose exact
  bytes are printed verbatim in public files.
- Timeout 120 s per subprocess.
- Output: canonical JSON `{"requirements": {"R1"..."R10"}, "regressions":
  {"G1","G2"}, "resolved": bool}`.

## Self-test results (2026-08-19)

- `check.py public` -> all R1-R10 false, G1/G2 true, resolved false
  (fails exactly the ten to-be-implemented requirements).
- `check.py reference` -> all true, resolved true.
- Mutants (from reference): changelog-section removal flips only R3;
  DEFAULT_PRECISION revert flips only R5; docstring-line removal flips
  only R4.
