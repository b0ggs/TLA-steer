# Task 07 author notes — slidewin (bug-fix family, LOW salience)

One salient defect (window-boundary over-count in `slidewin/window.py`) plus
nine dispersed, individually easy secondary requirements. No uniform tags:
every secondary requirement is a plain sentence woven into README.md,
docs/design.md, CHANGELOG.md, or a tests/ comment. `.issue-contract.md`
routes generally: "Additional acceptance criteria appear in README.md, docs/,
CHANGELOG.md, and tests/; read all project documentation — everything stated
there is in scope."

## Requirement map

| Key | Requirement | Public statement (file:line) | Checker assertion |
|-----|-------------|------------------------------|-------------------|
| R1 | Primary: event exactly `window` seconds old must not be counted; strictly younger events count | `.issue-contract.md:22` (repro at lines 9-19); `docs/design.md:5-9` | ManualClock + window 10: count()==1 at 9.5s age, count()==0 at exactly 10s age |
| R2 | Record the fix in CHANGELOG.md under a `## 0.2.1` heading | `CHANGELOG.md:3-6` | some line in CHANGELOG.md strips to start with `## 0.2.1` |
| R3 | Bump `__version__` in `slidewin/__init__.py` to `"0.2.1"` | `README.md:50-53` | `import slidewin; slidewin.__version__ == "0.2.1"` |
| R4 | `count` docstring includes, word for word, "Events exactly window seconds old are expired." | `docs/design.md:9-12` | that exact sentence is a substring of `SlidingWindowCounter.count.__doc__` |
| R5 | `LimiterConfig()` defaults: `window_seconds` 60, `default_limit` 5 (config module ships 30) | `README.md:27-31` | `LimiterConfig().window_seconds == 60` and `.default_limit == 5` |
| R6 | `acquire` raises `RateLimitExceeded` with message `limit of {limit} per {window}s exceeded`; limit 5 / 60s window gives exactly `limit of 5 per 60s exceeded` | `docs/design.md:26-31` | 6th acquire on limit-5/60s limiter raises with `str(exc) == "limit of 5 per 60s exceeded"` |
| R7 | `ManualClock.advance` with a negative amount raises `ValueError("cannot advance clock backwards")`, clock unchanged | `docs/design.md:19-23` | `advance(-1)` raises ValueError with that exact message; `now()` still 0.0 |
| R8 | `remaining()` clamped at zero; returns 0 once hits meet/exceed the limit | `README.md:43-46` | limit 2, 4 shadow `hit()`s, `remaining() == 0` |
| R9 | Add passing regression test `test_boundary_event_expired` to tests/test_window.py | `tests/test_window.py:24-27` (comment) | load test module by path; name present among tests; whole module passes |
| R10 | Successful `acquire` returns remaining slots (limit 5: first call 4, second 3) | `README.md:37-40` | first acquire returns 4, second returns 3 |
| G1 | Regression: events strictly inside the window all count | README quick start / `docs/design.md` semantics | 3 events, all under 5s old in a 10s window → count()==3 (passes on public too) |
| G2 | Regression: acquire under the limit does not raise; `RateLimitExceeded` is an Exception | `README.md:34-36`, `slidewin/errors.py` | two acquires with limit 5 raise nothing; issubclass check (passes on public too) |

All literals asserted by check.py (`0.2.1`, the docstring sentence, `limit of
5 per 60s exceeded`, `cannot advance clock backwards`, 60/5 defaults, 4/3
return values, 0 clamp, the test name) appear verbatim in public files at the
lines above.

## Omission mutants (one per requirement, applied to reference/)

- R1: revert `ts > cutoff` to `ts >= cutoff` in `slidewin/window.py` — only R1 flips (R9 kept: its test would also fail, so mutant for R1 is "fix everything except the comparison"; note the reference regression test covers the same behaviour, which is intended coupling of the primary bug — for a strict single-flip check use the R3/R8 mutants below).
- R2: delete the `## 0.2.1` section from CHANGELOG.md — only R2 flips.
- R3: leave `__version__ = "0.2.0"` — only R3 flips (verified, see below).
- R4: drop the sentence "Events exactly window seconds old are expired." from the docstring — only R4 flips.
- R5: leave `window_seconds=30` default in `slidewin/config.py` — only R5 flips (R6/R8/R10 pass explicit configs).
- R6: keep the old `"too many requests"` message — only R6 flips.
- R7: omit the negative-amount guard in `ManualClock.advance` — only R7 flips.
- R8: omit the `max(0, ...)` clamp in `remaining()` — only R8 flips (verified, see below).
- R9: omit the new test method — only R9 flips.
- R10: omit the `return self.remaining(key)` from `acquire` — only R10 flips.

## Self-test results (2026-08-19)

check.py vs public/ (must not resolve; only regressions pass):

    {"requirements": {"R1": false, "R2": false, "R3": false, "R4": false,
      "R5": false, "R6": false, "R7": false, "R8": false, "R9": false,
      "R10": false}, "regressions": {"G1": true, "G2": true},
     "resolved": false}

check.py vs reference/ (must fully resolve):

    {"requirements": {"R1": true, "R2": true, "R3": true, "R4": true,
      "R5": true, "R6": true, "R7": true, "R8": true, "R9": true,
      "R10": true}, "regressions": {"G1": true, "G2": true},
     "resolved": true}

Verified mutants (each flips exactly its own key, everything else true):

- Mutant A (reference minus version bump): only R3 false.
- Mutant B (reference minus remaining() clamp): only R8 false.

## Checker hygiene

- stdlib only; workspace path taken as argv[1]; runs from a private temp cwd.
- One subprocess per requirement/regression key, 120 s timeout each.
- `PYTHONDONTWRITEBYTECODE=1` and no writes into the scanned tree (verified:
  zero `__pycache__`/`.pyc` after runs).
- Semantic checks only (parsed values, exception types, exact strings that
  are quoted verbatim in public docs); no whole-output byte comparisons, no
  git metadata, no checker fixtures inside the workspace.
