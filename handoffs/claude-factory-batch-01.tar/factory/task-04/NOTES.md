# Task 04 — tocsmith `json` subcommand (family: feature-addition, salience: TAGGED)

Primary feature: add the `json` subcommand (JSON output mode) to the tocsmith
Markdown TOC generator, plus tagged release chores. Acceptance notes are
labeled FAC04-1..FAC04-10 and routed from `public/.issue-contract.md`:
"Acceptance notes tagged FAC04-* appear in README.md, docs/cli.md,
CHANGELOG.md, examples/; all are in scope." Requirement key Rn maps 1:1 to
note FAC04-n.

## Requirement map

| Key | Public statement (file:line) | Checker assertion | Omission mutant |
|-----|------------------------------|-------------------|-----------------|
| R1  | docs/cli.md:19 (FAC04-1; exact JSON block lines 26-59) | `python -m tocsmith json examples/sample.md` exits 0 and stdout == `json.dumps(EXPECTED_ENTRIES, indent=2) + "\n"` (bytes given verbatim in docs) | Omit the `json` subcommand handler entirely: R1 (and its siblings R2-R4) fail; nothing else moves |
| R2  | docs/cli.md:62 (FAC04-2) | `json --help` exits 0 and stdout contains `Emit the table of contents as JSON instead of Markdown.` | Register the subparser without the help/description sentence: only R2 flips |
| R3  | docs/cli.md:65 (FAC04-3) | headingless temp file (checker tmpdir): stdout == `[]\n`, exit code 3 | Return 0 instead of 3 for empty entries: only R3 flips |
| R4  | docs/cli.md:68 (FAC04-4) | missing file: exit 2 and stderr contains `tocsmith: error: cannot read ` | Let the open() OSError propagate for `json` (exit 1, traceback): only R4 flips |
| R5  | examples/README.md:7 (FAC04-5; content restated verbatim in docs/cli.md:26-59) | `examples/outline.json` parses to EXPECTED_ENTRIES | Omit creating examples/outline.json: only R5 flips |
| R6  | CHANGELOG.md:3 (FAC04-6) | CHANGELOG.md has a line starting `## 1.2.0` and a line equal to `` - Added the `json` subcommand. `` | Omit the changelog bullet: only R6 flips (verified) |
| R7  | README.md:23 (FAC04-7) | README.md has a line whose strip() == `Default JSON indent: 2 spaces; encoding: UTF-8.` | Omit the defaults line: only R7 flips |
| R8  | README.md:34 (FAC04-8) | `python -m unittest discover -s tests -p "test_json*.py" -v` exits 0, output names `test_json_entries_for_sample`, and is not "Ran 0 tests" | Omit tests/test_json.py: only R8 flips |
| R9  | CHANGELOG.md:7 (FAC04-9) | `--version` exits 0, stdout.strip() == `tocsmith 1.2.0` | Leave `__version__ = "1.1.0"`: only R9 flips (verified) |
| R10 | docs/cli.md:87 (FAC04-10) | `python -c "import tocsmith.scanner as s; print(s.scan_text('') == [])"` exits 0 printing `True` | Keep the unguarded `lines[0]` front-matter check: only R10 flips (verified) |

## Regressions

| Key | Public statement | Checker assertion |
|-----|------------------|-------------------|
| G1  | .issue-contract.md:15; docs/cli.md:13-15; examples/sample-toc.md (exact bytes) | `generate examples/sample.md` exits 0, stdout == sample-toc.md content |
| G2  | .issue-contract.md:17-19; README.md:28-31 | `unittest discover -s tests -p "test_core_*.py"` exits 0, runs > 0 tests |

## Checker design notes

- Stdlib only; workspace path is argv[1]; runs with cwd=workspace but lives
  outside it; PYTHONDONTWRITEBYTECODE=1 and COLUMNS=200 in every subprocess
  env; nothing written into the scanned tree (fixture files go to the
  checker's own TemporaryDirectory); 120 s timeout per subprocess; one
  subprocess per subprocess-based requirement (R5-R7 are pure file reads).
- R1's byte comparison is legal because docs/cli.md shows the exact output
  bytes; R5 is a parsed (semantic) JSON comparison.
- Public-state guards: R4 cannot pass via argparse's own "invalid choice"
  exit 2 (stderr must contain `cannot read`); R8 cannot pass via an empty
  discover run ("Ran 0 tests" rejected); R6/R7 note text cannot satisfy the
  line checks (notes embed the strings mid-sentence, checks are
  line-anchored).

## Self-test results (2026-08-19)

- check.py vs public/:
  `{"requirements": {"R1": false, ..., "R10": false}, "regressions": {"G1": true, "G2": true}, "resolved": false}` (all 10 R keys false)
- check.py vs reference/: all R and G keys true, `"resolved": true`
- Mutant A (drop changelog bullet): only R6 false
- Mutant B (revert scanner empty guard): only R10 false
- Mutant C (revert version bump): only R9 false
