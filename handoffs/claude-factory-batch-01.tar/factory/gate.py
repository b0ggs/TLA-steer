#!/usr/bin/env python3
"""Mechanical gate for factory tasks.

Usage: python3 gate.py <factory_dir> [--blind]

For each task-*/ directory:
  stage 1 (always):  check.py vs public/    -> must NOT resolve, regressions all pass
                     check.py vs reference/ -> must resolve, everything true
  stage 2 (--blind): check.py vs blind/     -> must resolve (blind/ is a solver's
                     contract-only solution); any failure = checker fidelity defect.

Exit code 0 iff every present task passes every applicable stage.
Prints one JSON line per task and a summary.
"""
import json
import subprocess
import sys
from pathlib import Path


def run_checker(check: Path, workspace: Path):
    try:
        proc = subprocess.run(
            [sys.executable, str(check), str(workspace)],
            capture_output=True, text=True, timeout=600,
        )
        line = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else ""
        return json.loads(line)
    except Exception as exc:  # noqa: BLE001 - gate reports, never crashes
        return {"error": f"{type(exc).__name__}: {exc}"}


def main():
    factory = Path(sys.argv[1])
    blind = "--blind" in sys.argv
    results, ok_count = [], 0
    for task_dir in sorted(factory.glob("task-*")):
        check = task_dir / "check.py"
        row = {"task": task_dir.name, "ok": False, "reasons": []}
        if not check.is_file():
            row["reasons"].append("missing check.py")
        else:
            pub = run_checker(check, task_dir / "public")
            ref = run_checker(check, task_dir / "reference")
            if pub.get("error") or ref.get("error"):
                row["reasons"].append(f"checker error pub={pub.get('error')} ref={ref.get('error')}")
            else:
                if pub.get("resolved") is not False:
                    row["reasons"].append("public unexpectedly resolves")
                if not all(pub.get("regressions", {}).values()):
                    row["reasons"].append("regressions fail on pristine public")
                if ref.get("resolved") is not True:
                    failed = [k for k, v in {**ref.get("requirements", {}), **ref.get("regressions", {})}.items() if not v]
                    row["reasons"].append(f"reference fails: {failed}")
                row["n_requirements"] = len(pub.get("requirements", {}))
            if blind:
                bl = run_checker(check, task_dir / "blind")
                if bl.get("error"):
                    row["reasons"].append(f"blind checker error {bl['error']}")
                elif bl.get("resolved") is not True:
                    failed = [k for k, v in {**bl.get("requirements", {}), **bl.get("regressions", {})}.items() if not v]
                    row["reasons"].append(f"BLIND SOLUTION REJECTED (fidelity defect): {failed}")
        row["ok"] = not row["reasons"]
        ok_count += row["ok"]
        results.append(row)
        print(json.dumps(row))
    total = len(results)
    print(json.dumps({"summary": f"{ok_count}/{total} pass", "blind_stage": blind}))
    sys.exit(0 if ok_count == total and total else 1)


if __name__ == "__main__":
    main()
