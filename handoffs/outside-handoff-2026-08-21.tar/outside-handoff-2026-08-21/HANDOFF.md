# Outside review handoff — 21 August 2026

## What we are trying to build

We are building an open-source benchmark that answers a practical question for a
team using a coding agent: does a repository instruction file such as `CODER.md`
or `AGENTS.md` help the agent, hurt it, or merely cost more money?

The benchmark gives the same model the same coding tasks under controlled
conditions. In one arm the project has no instruction file. In another it has a
specified instruction file. A later comparison can test the current file against
a proposed replacement. Automated checks decide whether the requested work was
completed and whether existing behavior was preserved. Repeated paired runs are
used because a single model run is too noisy to support a decision.

The intended product is the task collection, runner, checks, preserved evidence,
and comparison report needed to make a reliable keep, replace, or remove
decision. It is not yet a system that writes or optimizes instruction files.

In product terms:

- An instruction file **helps** if it raises successful completion or achieves
  the same completion with meaningfully lower cost.
- It **hurts** if it lowers completion, causes regressions, or materially raises
  cost.
- It **wastes money** if outcomes are practically unchanged while tokens, time,
  or tool use increase.

## What is built and has been exercised

Each task is a small starting project plus independent fairness checks. `public/`
is what the tested model sees, `reference/` is a known-correct solution, and
`blind/` is a solution made independently from the public project alone.
`check.py` is the objective grader. The requirements file defines what is tested,
and the manifest binds an admitted task to exact file hashes.

`taskcheck.py` refuses a task unless the untouched project fails, both solutions
pass, the grader is deterministic, and individual omissions can be detected.
Newer tasks also prove that requirements are stated publicly and are not copied
into one convenient master list. Instruction-file names and contents may not
leak into grading.

The rest of the task pipeline is also implemented:

- `taskgen.py` creates a candidate from a recipe; it remains untrusted until
  admission succeeds.
- `blindsolve.py` gives only the public project to a separate solving agent,
  records what was run, and refuses to alter a task after live exposure.
- `run_batch.py` runs one or two arms with equal task bytes and model settings,
  alternating order and preserving evidence. Before spending money it binds all
  inputs and the maximum call count into a request, then requires a human
  approval containing that request's exact hash.
- `compare.py` verifies the result chain, compares paired arm scores, and reports
  arm A better, arm B better, inconclusive, or invalid. Small or badly
  unbalanced samples cannot be presented as wins.

The implementation uses the Python standard library. Offline tests cover the
whole pipeline, tampering, approval refusal, equal-arm controls, known winners,
and statistical direction. At handoff, 188 tests passed and 6 were skipped; no
test path calls a live model. The newest batch passes its evidence verifier.

## What the experiments have shown

Only tasks with sound graders and public instructions count. Apparent failures
caused by hidden requirements, contradictory scope, or brittle grading are
recorded but excluded.

The brief empirical record for `gpt-5.6-sol` is:

- In the M2 v0.4/v0.4.1 campaign, 14 sound tasks were solved in every repeated
  attempt; six other tasks had faulty hidden requirements and do not count.
- In `scout-v1`, four sound tasks were solved 3 out of 3 times; two tasks with
  scope-routing defects do not count.
- Sound rolling tasks such as the badge tool and the original `durafmt` task
  were each solved 3 out of 3 times. Several other rolling tasks were rejected
  after grader or fidelity defects were found.
- The `salience-probe-v2` batch removed prominent requirement signposting from
  `durafmt`. The bare model still solved all 3 attempts: quality 1.0, score 3,
  ceiling.
- The `low-salience-null-v3` batch used five independently admitted tasks whose
  requirements were spread across several ordinary project files. The bare
  model solved all 15 attempts. Every task had quality 1.0, score 3, ceiling;
  no replacement call was needed.

One historical exception matters. `scout-c-integration-01` was checker-sound but
resolved only 1 of 3 runs, with 0.9167 requirement coverage because a stated test
was missed twice. A stated requirement can therefore be missed; not literally
every sound historical task was perfect. The exception did not become a
reproducible difficulty band.

The defensible conclusion is therefore narrower and still consequential: for
this model and projects of this size, trying to manufacture sensitivity by
hiding, dispersing, or softly pointing to already stated requirements has not
produced a useful benchmark cohort. Both modern salience experiments saturated
completely. Continuing to make the model overlook stated requirements looks like
a dead end unless task scale or structure changes substantially.

## The next hypothesis worth testing

An instruction file may instead supply project-specific information that is
expensive or unreliable to infer quickly: the exact test command, an environment
variable, a generated-file rule, a local service sequence, a compatibility
constraint, or a project-specific workaround.

The key hypothesis is that instruction files close these **information gaps**
and reduce **cost**. They may not make an already thorough frontier model more
thorough. They may instead help it finish within a fixed budget, use fewer
tokens, avoid fruitless exploration, or reach the same correct answer faster.

The proposed experiment uses information-gap tasks. Each remains solvable without
the file through inspection or experimentation, but the missing fact imposes a
real search cost. A helpful file states it accurately. Bare and file-equipped
arms otherwise receive identical projects, settings, time limits, and token
budgets. Order is paired and balanced, tasks freeze before outcomes, and
objective checks still decide correctness.

The primary outcome should be completion within a prospectively fixed budget.
Secondary outcomes should include requirements completed, input and output
tokens, wall-clock time, tool calls, and estimated monetary cost. An equal-file
control should estimate ordinary run noise. The decision rule should distinguish
better completion, equal completion at lower cost, equal performance with no
meaningful cost change, and harmful regressions. Current evidence already records
duration and the raw model event stream; token and cost fields should be promoted
into a stable comparison result before this experiment is used for decisions.

## What is in this archive

- `HANDOFF.md`: this overview and the questions below.
- `TASK_TOOLING_V2_PLAN.md`: the governing development specification.
- `handoffs/PROCESS_FINDINGS_2026-08-19.md`: the detailed experimental and
  process record, including invalid runs and the historical intermediate result.
- `roadmap.md`: the path from statistics to an open-source release, paid pilots,
  regression subscriptions, and eventually an optimization loop.
- `tooling/`: all source, tests, prompts, and user documentation for task
  generation, independent solving, admission, and comparison. Generated Python
  bytecode is intentionally omitted.
- `scripts/run_batch.py` and `scripts/import/`: the controlled runner and the
  one-time task import helper.
- `tasks/fac-01/`: a complete example with prominently enumerated requirements.
- `tasks/fac-07/`: a complete low-salience example with requirements spread
  through project documentation.
- `runs/dev-v2/salience-probe-v2/`: only its request, approval, final task
  disposition, and one representative attempt result.
- `runs/dev-v2/low-salience-null-v3/`: only its request, approval, five final
  task dispositions, and one representative attempt result.

Raw model event logs, credentials, caches, repository history, large historical
archives, and unrelated frozen runs are deliberately absent.

## Questions for the outside reviewer

1. Is the information-gap and cost hypothesis the right pivot given the record,
   or is there a better mechanism by which project instructions could add value?
2. How would you design information-gap tasks that are realistic and fair rather
   than making the bare arm artificially impossible?
3. Which task families would best separate saved exploration from simple prompt
   leakage, and how diverse must the suite be?
4. What primary outcome, budget, equivalence margin, sample size, and paired
   statistical rule should be fixed before running the experiment?
5. How should tokens, cached tokens, wall time, tool calls, and model-service
   variance be normalized into a defensible cost comparison?
6. What controls or falsification tests are missing? In particular, should we
   include irrelevant, stale, misleading, or overly long instruction files?
7. Does the current task and evidence design support a credible open-source
   benchmark, and what must be simplified or hardened before outside teams use it?

Please separate flaws that would invalidate the next experiment from useful
future refinements. We especially want a concrete experiment design, not another
general process layer.
